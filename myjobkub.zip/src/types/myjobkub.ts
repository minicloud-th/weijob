export type PageKey = 'หน้าหลัก' | 'สั่งงาน' | 'งานของฉัน' | 'เติมเงิน' | 'ตั้งค่า';

export type ThemeMode = 'system' | 'light' | 'dark';

export type OrderStatus = 'รอราคา' | 'เสนอราคาแล้ว' | 'ยืนยันแล้ว' | 'เสร็จแล้ว';

export type GradeLevel = 'ม.1' | 'ม.2' | 'ม.3';

export type TopUpChannel = 'truemoney' | 'bank' | 'cash' | 'giftcode';

export type TopUpStatus = 'รอตรวจสอบ' | 'สำเร็จ' | 'ไม่ผ่าน';

export interface Order {
  id: string;
  title: string;
  lv: string;
  qty: string;
  due: string;
  note: string;
  images?: string[];
  contact: string;
  price: number | null;
  status: OrderStatus;
  paid?: boolean;
}

export interface OrderDraft {
  title: string;
  lv: string;
  room: string;
  qty: string;
  due: string;
  note: string;
  images?: string[];
  contact: string;
  isStudent: boolean;
}

export interface TopUpRecord {
  id: string;
  channel: TopUpChannel;
  amount: number;
  status: TopUpStatus;
  createdAt: string;
  contact: string;
  walletPhone?: string;
  reference?: string;
  bankName?: string;
  slipImage?: string;
  meetupLocation?: string;
  note?: string;
  giftCode?: string;
}

export interface GiftCodeItem {
  code: string;
  amount: number;
}

export interface AppState {
  in: boolean;
  name: string;
  contact: string;
  mode: ThemeMode;
  accent: string;
  orders: Order[];
  topups: TopUpRecord[];
  giftCodes: GiftCodeItem[];
  usedGiftCodes: string[];
  admin: boolean;
  pin: string;
  lv: string;
}
