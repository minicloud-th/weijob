import { useEffect, useRef, useState } from 'react';
import type { AppState, OrderDraft, PageKey, ThemeMode } from './types/myjobkub';
import {
  applyThemeToDocument,
  completeOrder,
  confirmOrder,
  createOrder,
  deleteOrder,
  getPendingBadgeCount,
  loadAppState,
  payOrderFromWallet,
  saveAppState,
  setOrderPrice,
} from './utils/myjobkubLogic';
import {
  approveTopUp,
  createTopUpRecord,
  getPendingTopUpCount,
  getWalletBalance,
  redeemGiftCode,
  rejectTopUp,
  type TopUpDraft,
} from './utils/topupLogic';
import { extractVoucherHash } from './utils/angpaoLogic';
import { LoginView } from './components/LoginView';
import { NavRail } from './components/NavRail';
import { HomeView } from './components/HomeView';
import { OrderFormView } from './components/OrderFormView';
import { OrdersView } from './components/OrdersView';
import { TopUpView } from './components/TopUpView';
import { SettingsView } from './components/SettingsView';

export default function App() {
  const [state, setState] = useState<AppState>(() => {
    const loaded = loadAppState(typeof window !== 'undefined' ? window.localStorage : undefined);
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1' && !loaded.in) {
        return {
          ...loaded,
          in: true,
          contact: loaded.contact || 'student@srimuang.ac.th',
        };
      }
    }
    return loaded;
  });

  const [currentPage, setCurrentPage] = useState<PageKey>('หน้าหลัก');
  const pageContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    applyThemeToDocument(state.mode, state.accent, document);
    saveAppState(state, window.localStorage);
  }, [state]);

  const navigateTo = (page: PageKey) => {
    setCurrentPage(page);
    if (pageContainerRef.current) {
      pageContainerRef.current.scrollTop = 0;
    }
  };

  const handleLogin = (contact: string) => {
    setState((prev) => ({ ...prev, in: true, contact }));
    navigateTo('หน้าหลัก');
  };

  const handleLogout = () => {
    setState((prev) => ({ ...prev, in: false, admin: false }));
    setCurrentPage('หน้าหลัก');
  };

  const handleSubmitOrder = (draft: OrderDraft) => {
    const newOrder = createOrder(draft);
    setState((prev) => ({
      ...prev,
      contact: draft.contact.trim(),
      orders: [newOrder, ...prev.orders],
    }));
    navigateTo('งานของฉัน');
  };

  const handleSetPrice = (orderId: string, rawPrice: string): boolean => {
    const updated = setOrderPrice(state.orders, orderId, rawPrice);
    if (!updated) return false;
    setState((prev) => ({ ...prev, orders: updated }));
    return true;
  };

  const handleConfirmOrder = (orderId: string) => {
    setState((prev) => ({ ...prev, orders: confirmOrder(prev.orders, orderId) }));
  };

  const handlePayOrder = (orderId: string) => {
    const order = state.orders.find((o) => o.id === orderId);
    const balance = getWalletBalance(state.topups, state.orders);
    if (!order || order.price == null || order.paid || balance < order.price) return;
    setState((prev) => ({ ...prev, orders: payOrderFromWallet(prev.orders, orderId) }));
  };

  const handleCompleteOrder = (orderId: string) => {
    setState((prev) => ({ ...prev, orders: completeOrder(prev.orders, orderId) }));
  };

  const handleDeleteOrder = (orderId: string) => {
    setState((prev) => ({ ...prev, orders: deleteOrder(prev.orders, orderId) }));
  };

  const handleSubmitTopUp = (draft: TopUpDraft) => {
    const record = createTopUpRecord(draft);
    setState((prev) => ({ ...prev, topups: [record, ...prev.topups] }));
  };

  const handleRedeemAngpao = async (
    voucherUrl: string
  ): Promise<{ ok: true; amount: number; ownerName: string } | { ok: false; error: string }> => {
    const hash = extractVoucherHash(voucherUrl);
    if (!hash) {
      return {
        ok: false,
        error: 'ลิงก์ซองอั่งเปาไม่ถูกต้อง กรุณาวางลิงก์ https://gift.truemoney.com/campaign/?v=...',
      };
    }

    const alreadyRedeemed = state.topups.some(
      (t) => t.channel === 'truemoney' && t.reference === hash && t.status === 'สำเร็จ'
    );
    if (alreadyRedeemed) {
      return { ok: false, error: 'ซองอั่งเปานี้ถูกเติมเข้าระบบไปแล้ว' };
    }

    try {
      const res = await fetch('/api/angpao/redeem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ voucherUrl }),
      });
      const data = (await res.json()) as {
        ok?: boolean;
        voucherHash?: string;
        amountBaht?: number;
        ownerName?: string;
        error?: string;
      };

      if (!res.ok || !data.ok || typeof data.amountBaht !== 'number') {
        return {
          ok: false,
          error: data.error ?? 'รับซองอั่งเปาไม่สำเร็จ กรุณาตรวจสอบข้อมูลอีกครั้ง',
        };
      }

      const redeemedRecord = {
        id: `top-${Date.now().toString(36)}`,
        channel: 'truemoney' as const,
        amount: data.amountBaht,
        status: 'สำเร็จ' as const,
        createdAt: new Date().toISOString(),
        contact: state.contact,
        reference: data.voucherHash ?? hash,
      };

      setState((prev) => ({ ...prev, topups: [redeemedRecord, ...prev.topups] }));
      return { ok: true, amount: data.amountBaht, ownerName: data.ownerName ?? '' };
    } catch {
      return {
        ok: false,
        error: 'ไม่สามารถเชื่อมต่อระบบตรวจซองอั่งเปาได้ในขณะนี้',
      };
    }
  };

  const handleRedeemGiftCode = (
    rawCode: string
  ): { ok: true; amount: number } | { ok: false; error: string } => {
    const res = redeemGiftCode(rawCode, state.giftCodes, state.usedGiftCodes, state.contact);
    if (!res.ok) return { ok: false, error: res.error };
    setState((prev) => ({
      ...prev,
      topups: [res.record, ...prev.topups],
      usedGiftCodes: [...prev.usedGiftCodes, res.normalizedCode],
    }));
    return { ok: true, amount: res.record.amount };
  };

  const handleApproveTopUp = (id: string) => {
    setState((prev) => ({ ...prev, topups: approveTopUp(prev.topups, id) }));
  };

  const handleRejectTopUp = (id: string) => {
    setState((prev) => ({ ...prev, topups: rejectTopUp(prev.topups, id) }));
  };

  const handleAddGiftCode = (code: string, amount: number) => {
    setState((prev) => ({
      ...prev,
      giftCodes: prev.giftCodes.some((g) => g.code === code)
        ? prev.giftCodes.map((g) => (g.code === code ? { code, amount } : g))
        : [{ code, amount }, ...prev.giftCodes],
    }));
  };

  if (!state.in) {
    return <LoginView onLogin={handleLogin} />;
  }

  const pageTitle = currentPage === 'งานของฉัน' && state.admin ? 'งานทั้งหมด' : currentPage;
  const badgeCount = getPendingBadgeCount(state.orders, state.admin);
  const topupBadgeCount = state.admin ? getPendingTopUpCount(state.topups) : 0;
  const walletBalance = getWalletBalance(state.topups, state.orders);

  return (
    <main id="chat" className="h-full flex" style={{ background: 'var(--chatbg)' }}>
      <NavRail
        currentPage={currentPage}
        badgeCount={badgeCount}
        topupBadgeCount={topupBadgeCount}
        onNavigate={navigateTo}
      />

      <section className="flex-1 min-w-0 flex flex-col relative">
        <div className="absolute inset-x-0 top-0 py-3.5 px-4 z-[2] pointer-events-none">
          <span
            id="ttl"
            className="inline-flex py-2.5 px-3.5 rounded-[14px] text-[15px] font-semibold"
            style={{ background: 'var(--panel)' }}
          >
            {pageTitle}
          </span>
        </div>

        <div ref={pageContainerRef} id="page" className="flex-1 overflow-y-auto pt-[72px] px-5 pb-7">
          <div key={currentPage} className="max-w-[640px] mx-auto mjk-page-enter">
            {currentPage !== 'หน้าหลัก' ? (
              <h2 className="mt-0 mb-1.5 text-[28px] font-bold tracking-[-0.01em]">
                {pageTitle}
              </h2>
            ) : null}

            {currentPage === 'หน้าหลัก' ? (
              <HomeView name={state.name} onOrderClick={() => navigateTo('สั่งงาน')} />
            ) : null}

            {currentPage === 'สั่งงาน' ? (
              <OrderFormView
                selectedLevel={state.lv}
                defaultContact={state.contact}
                onSelectLevel={(lv) => setState((prev) => ({ ...prev, lv }))}
                onSubmitOrder={handleSubmitOrder}
              />
            ) : null}

            {currentPage === 'งานของฉัน' ? (
              <OrdersView
                orders={state.orders}
                isAdmin={state.admin}
                walletBalance={walletBalance}
                onGoOrder={() => navigateTo('สั่งงาน')}
                onGoTopUp={() => navigateTo('เติมเงิน')}
                onSetPrice={handleSetPrice}
                onConfirmOrder={handleConfirmOrder}
                onPayOrder={handlePayOrder}
                onCompleteOrder={handleCompleteOrder}
                onDeleteOrder={handleDeleteOrder}
              />
            ) : null}

            {currentPage === 'เติมเงิน' ? (
              <TopUpView
                contact={state.contact}
                walletBalance={walletBalance}
                topups={state.topups}
                giftCodes={state.giftCodes}
                usedGiftCodes={state.usedGiftCodes}
                isAdmin={state.admin}
                onSubmitTopUp={handleSubmitTopUp}
                onRedeemAngpao={handleRedeemAngpao}
                onRedeemGiftCode={handleRedeemGiftCode}
                onApproveTopUp={handleApproveTopUp}
                onRejectTopUp={handleRejectTopUp}
                onAddGiftCode={handleAddGiftCode}
              />
            ) : null}

            {currentPage === 'ตั้งค่า' ? (
              <SettingsView
                name={state.name}
                contact={state.contact}
                orders={state.orders}
                mode={state.mode}
                accent={state.accent}
                isAdmin={state.admin}
                adminPin={state.pin}
                onUpdateName={(name) => setState((prev) => ({ ...prev, name }))}
                onUpdateContact={(contact) => setState((prev) => ({ ...prev, contact }))}
                onChangeMode={(mode: ThemeMode) => setState((prev) => ({ ...prev, mode }))}
                onChangeAccent={(accent) => setState((prev) => ({ ...prev, accent }))}
                onEnterAdmin={() => setState((prev) => ({ ...prev, admin: true }))}
                onExitAdmin={() => setState((prev) => ({ ...prev, admin: false }))}
                onChangePin={(pin) => setState((prev) => ({ ...prev, pin }))}
                onWipeOrders={() => setState((prev) => ({ ...prev, orders: [] }))}
                onLogout={handleLogout}
              />
            ) : null}
          </div>
        </div>
      </section>
    </main>
  );
}
