import test from 'node:test';
import assert from 'node:assert/strict';
import {
  BANK_LIST,
  BANK_RECEIVER_ACCOUNT,
  CASH_MEETUP_LOCATION,
  DEFAULT_GIFT_CODES,
  TOPUP_CHANNELS,
  approveTopUp,
  createTopUpRecord,
  getBankLogo,
  getPendingTopUpAmount,
  getWalletBalance,
  normalizeTopUpRecord,
  redeemGiftCode,
  rejectTopUp,
  validateBankStepOne,
  validateTopUpDraft,
} from './topupLogic';
import type { Order, TopUpRecord } from '../types/myjobkub';

test('validateTopUpDraft enforces channel-specific required fields', () => {
  const base = {
    channel: 'truemoney' as const,
    amount: '100',
    contact: '0812345678',
    walletPhone: '0891112222',
    reference: 'TMN-8899',
    bankName: 'กสิกรไทย (KBank)',
    slipImage: 'data:image/jpeg;base64,fake-slip',
    meetupLocation: CASH_MEETUP_LOCATION,
    note: '',
    giftCode: '',
  };

  assert.equal(validateTopUpDraft(base), null);
  assert.ok(validateTopUpDraft({ ...base, amount: '0' }));
  assert.ok(validateTopUpDraft({ ...base, walletPhone: '123' }));
  assert.ok(validateTopUpDraft({ ...base, reference: '' }));

  // Bank uses slipImage instead of reference
  assert.equal(validateTopUpDraft({ ...base, channel: 'bank', reference: '' }), null);
  assert.ok(validateTopUpDraft({ ...base, channel: 'bank', bankName: '' }));
  assert.ok(validateTopUpDraft({ ...base, channel: 'bank', slipImage: '' }));

  assert.equal(validateBankStepOne('250', 'กสิกรไทย (KBank)'), null);
  assert.ok(validateBankStepOne('0', 'กสิกรไทย (KBank)'));
  assert.ok(validateBankStepOne('250', ''));

  const bankRec = createTopUpRecord(
    { ...base, channel: 'bank', reference: '' },
    'b1',
    '2026-11-16T10:00:00Z'
  );
  assert.equal(bankRec.reference, undefined);
  assert.equal(bankRec.slipImage, 'data:image/jpeg;base64,fake-slip');
  const normalizedBank = normalizeTopUpRecord(bankRec as unknown as Record<string, unknown>);
  assert.equal(normalizedBank?.slipImage, 'data:image/jpeg;base64,fake-slip');

  assert.equal(validateTopUpDraft({ ...base, channel: 'cash', meetupLocation: '' }), null);
  const cashRec = createTopUpRecord({ ...base, channel: 'cash', meetupLocation: '' }, 'c1', '2026-11-16T10:00:00Z');
  assert.equal(cashRec.meetupLocation, 'หน้าห้อง 226');

  assert.ok(validateTopUpDraft({ ...base, channel: 'giftcode', giftCode: '' }));
  assert.equal(validateTopUpDraft({ ...base, channel: 'giftcode', giftCode: 'WEI50' }), null);
});

test('redeemGiftCode handles valid, case-insensitive, invalid, and duplicate codes', () => {
  const res1 = redeemGiftCode(' wei50 ', DEFAULT_GIFT_CODES, [], '0812345678', 't1', '2026-11-16T10:00:00Z');
  assert.equal(res1.ok, true);
  if (res1.ok) {
    assert.equal(res1.normalizedCode, 'WEI50');
    assert.equal(res1.record.amount, 50);
    assert.equal(res1.record.status, 'สำเร็จ');
  }

  const dup = redeemGiftCode('WEI50', DEFAULT_GIFT_CODES, ['WEI50'], '0812345678');
  assert.equal(dup.ok, false);

  const bad = redeemGiftCode('NOPE999', DEFAULT_GIFT_CODES, [], '0812345678');
  assert.equal(bad.ok, false);
});

test('wallet balance updates on approval, rejection, and paid orders', () => {
  const tm = createTopUpRecord(
    {
      channel: 'truemoney',
      amount: '150',
      contact: '0812345678',
      walletPhone: '0891112222',
      reference: 'TMN-1',
      bankName: '',
      meetupLocation: '',
      note: '',
      giftCode: '',
    },
    't-tm',
    '2026-11-16T10:00:00Z'
  );
  const gift = redeemGiftCode('WEI100', DEFAULT_GIFT_CODES, [], '0812345678', 't-gc', '2026-11-16T10:01:00Z');
  assert.equal(gift.ok, true);

  let topups: TopUpRecord[] = [tm, ...(gift.ok ? [gift.record] : [])];
  const orders: Order[] = [
    {
      id: 'o1',
      title: 'ใบงานวิทย์',
      lv: 'ม.2',
      qty: '2 หน้า',
      due: '20 พ.ย.',
      note: '',
      contact: '0812345678',
      price: 80,
      status: 'ยืนยันแล้ว',
      paid: true,
    },
  ];

  assert.equal(getWalletBalance(topups, orders), 20);
  assert.equal(getPendingTopUpAmount(topups), 150);

  topups = approveTopUp(topups, 't-tm');
  assert.equal(getWalletBalance(topups, orders), 170);
  assert.equal(getPendingTopUpAmount(topups), 0);

  topups = rejectTopUp(topups, 't-tm');
  assert.equal(getWalletBalance(topups, orders), 20);
});

import { EMBEDDED_LOGOS } from './embeddedLogos';

test('channels and Thai banks map to valid embedded brand logos', () => {
  assert.equal(TOPUP_CHANNELS.length, 4);
  for (const ch of TOPUP_CHANNELS) {
    assert.ok(ch.logo.startsWith('data:image/'));
  }
  assert.equal(BANK_LIST.length, 20);
  for (const b of BANK_LIST) {
    assert.ok(b.logo.startsWith('data:image/png;base64,'));
  }
  assert.equal(getBankLogo('กสิกรไทย (KBank)'), EMBEDDED_LOGOS.KBANK);
  assert.equal(getBankLogo('ไทยพาณิชย์ (SCB)'), EMBEDDED_LOGOS.SCB);
  assert.equal(getBankLogo('ออมสิน (GSB)'), EMBEDDED_LOGOS.GSB);
  assert.equal(getBankLogo('ธ.ก.ส. (BAAC)'), EMBEDDED_LOGOS.BAAC);
  assert.equal(getBankLogo('ไม่ระบุ'), EMBEDDED_LOGOS.PromptPay);
  assert.equal(BANK_RECEIVER_ACCOUNT.accountNumber, '1963870325');
  assert.equal(BANK_RECEIVER_ACCOUNT.accountName, 'กรวิชญ์');
  assert.equal(BANK_RECEIVER_ACCOUNT.bankName, 'กสิกรไทย (KBank)');
  assert.ok(BANK_RECEIVER_ACCOUNT.logo.startsWith('data:image/png;base64,'));
});
