import type { AppState, GradeLevel, GiftCodeItem, Order, OrderDraft, ThemeMode, TopUpRecord } from '../types/myjobkub';
import { DEFAULT_GIFT_CODES, normalizeTopUpRecord } from './topupLogic';

export const STORAGE_KEY = 'mjk';

export const MAX_ORDER_IMAGES = 10;

export const GRADES: GradeLevel[] = ['ม.1', 'ม.2', 'ม.3'];

export const ACCENTS: string[] = [
  '#4a8dff',
  '#1fa3e8',
  '#a855f7',
  '#ec4899',
  '#f59e0b',
  '#84cc16',
];

export interface WeiVariant {
  text: string;
  lang: string;
  label: string;
}

export const WEI_VARIANTS: WeiVariant[] = [
  { text: 'wei', lang: 'en', label: 'English' },
  { text: 'เหวย', lang: 'th', label: 'ไทย' },
  { text: '伟', lang: 'zh', label: '中文' },
  { text: 'ウェイ', lang: 'ja', label: '日本語' },
  { text: '웨이', lang: 'ko', label: '한국어' },
  { text: 'Vĩ', lang: 'vi', label: 'Tiếng Việt' },
];

export function getNextWeiIndex(currentIndex: number, total = WEI_VARIANTS.length): number {
  if (total <= 0) return 0;
  return (currentIndex + 1) % total;
}

export const DEFAULT_STATE: AppState = {
  in: false,
  name: '',
  contact: '',
  mode: 'system',
  accent: '#4a8dff',
  orders: [],
  topups: [],
  giftCodes: DEFAULT_GIFT_CODES,
  usedGiftCodes: [],
  admin: false,
  pin: '1234',
  lv: '',
};

export function isValidContact(value: string): boolean {
  const v = value.trim();
  return /^\S+@\S+\.\S+$/.test(v) || /^\+?[\d\s().-]{7,}$/.test(v);
}

export function formatBaht(amount: number): string {
  return '฿' + amount.toLocaleString('en-US');
}

export function formatThaiDueDate(isoDate: string): string {
  const normalized = /^\d{4}-\d{2}-\d{2}$/.test(isoDate) ? `${isoDate}T00:00:00` : isoDate;
  return new Date(normalized).toLocaleDateString('th-TH', {
    day: 'numeric',
    month: 'short',
  });
}

export function getTodayIsoDate(now = new Date()): string {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function isJuniorHighLevel(lv: string): boolean {
  return GRADES.includes(lv as GradeLevel);
}

export function normalizeOrder(raw: Record<string, unknown>, fallbackContact = ''): Order {
  const images = Array.isArray(raw?.images)
    ? raw.images.filter((src): src is string => typeof src === 'string' && src.length > 0)
    : undefined;
  if (raw && typeof raw.status === 'string') {
    return {
      id: String(raw.id ?? Date.now().toString(36)),
      title: String(raw.title ?? ''),
      lv: String(raw.lv ?? ''),
      qty: String(raw.qty ?? ''),
      due: String(raw.due ?? ''),
      note: String(raw.note ?? ''),
      ...(images && images.length > 0 ? { images } : {}),
      contact: String(raw.contact ?? fallbackContact),
      price: typeof raw.price === 'number' ? raw.price : null,
      status: raw.status as Order['status'],
      ...(raw.paid === true ? { paid: true } : {}),
    };
  }
  const t = typeof raw?.t === 'string' && raw.t ? `${raw.t}: ` : '';
  const q = raw?.q != null ? String(raw.q) : '';
  const u = typeof raw?.u === 'string' ? raw.u : '';
  return {
    id: String(raw?.id ?? Date.now().toString(36)),
    title: `${t}${String(raw?.title ?? '')}`,
    lv: String(raw?.lv ?? ''),
    qty: `${q} ${u}`.trim(),
    due: String(raw?.due ?? ''),
    note: String(raw?.note ?? ''),
    ...(images && images.length > 0 ? { images } : {}),
    contact: fallbackContact,
    price: null,
    status: 'รอราคา',
  };
}

export function loadAppState(storage?: Pick<Storage, 'getItem'>): AppState {
  const fallback: AppState = { ...DEFAULT_STATE, orders: [] };
  if (!storage) return fallback;
  try {
    const raw = storage.getItem(STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as Omit<
      Partial<AppState>,
      'in' | 'admin' | 'orders' | 'topups' | 'giftCodes' | 'usedGiftCodes'
    > & {
      in?: boolean | number;
      admin?: boolean | number;
      orders?: Array<Record<string, unknown>>;
      topups?: Array<Record<string, unknown>>;
      giftCodes?: Array<Record<string, unknown>>;
      usedGiftCodes?: unknown[];
    };
    const contact = typeof parsed.contact === 'string' ? parsed.contact : '';
    const orders = Array.isArray(parsed.orders)
      ? parsed.orders.map((o) => normalizeOrder(o, contact))
      : [];
    const topups: TopUpRecord[] = Array.isArray(parsed.topups)
      ? parsed.topups
          .map((t) => normalizeTopUpRecord(t))
          .filter((t): t is TopUpRecord => t !== null)
      : [];
    const giftCodes: GiftCodeItem[] = Array.isArray(parsed.giftCodes)
      ? parsed.giftCodes
          .filter(
            (g): g is Record<string, unknown> =>
              Boolean(g) && typeof g.code === 'string' && typeof g.amount === 'number'
          )
          .map((g) => ({ code: String(g.code).toUpperCase(), amount: Number(g.amount) }))
      : DEFAULT_GIFT_CODES;
    const usedGiftCodes: string[] = Array.isArray(parsed.usedGiftCodes)
      ? parsed.usedGiftCodes.filter((c): c is string => typeof c === 'string')
      : [];
    const savedLv = typeof parsed.lv === 'string' ? parsed.lv : '';
    return {
      in: Boolean(parsed.in),
      name: typeof parsed.name === 'string' ? parsed.name : '',
      contact,
      mode: parsed.mode === 'light' || parsed.mode === 'dark' || parsed.mode === 'system'
        ? parsed.mode
        : 'system',
      accent: typeof parsed.accent === 'string' && parsed.accent ? parsed.accent : '#4a8dff',
      orders,
      topups,
      giftCodes: giftCodes.length > 0 ? giftCodes : DEFAULT_GIFT_CODES,
      usedGiftCodes,
      admin: Boolean(parsed.admin),
      pin: typeof parsed.pin === 'string' && parsed.pin ? parsed.pin : '1234',
      lv: isJuniorHighLevel(savedLv) ? savedLv : '',
    };
  } catch {
    return fallback;
  }
}

export function saveAppState(state: AppState, storage?: Pick<Storage, 'setItem'>): void {
  if (!storage) return;
  try {
    storage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage quota errors
  }
}

export interface ValidationError {
  field: 'o1' | 'lv' | 'o4' | 'o6' | 'o8';
  message: string;
}

export function validateOrderInput(draft: OrderDraft): ValidationError | null {
  if (!draft.title.trim()) {
    return { field: 'o1', message: 'ยังไม่ได้พิมพ์งานเลย' };
  }
  if (!isJuniorHighLevel(draft.lv.trim())) {
    return { field: 'lv', message: 'เลือกชั้น ม.ต้น ก่อนนะ (รับเฉพาะ ม.1–ม.3)' };
  }
  if (!draft.due.trim()) {
    return { field: 'o4', message: 'เลือกวันที่ต้องส่งด้วยนะ' };
  }
  if (!draft.contact.trim()) {
    return { field: 'o6', message: 'ใส่เบอร์หรืออีเมลให้ wei ทักกลับด้วยนะ' };
  }
  if (!draft.isStudent) {
    return { field: 'o8', message: 'ติ๊กยืนยันว่าเป็นนักเรียน ม.ต้น โรงเรียนศรีเมืองวิทยาคารก่อนนะ' };
  }
  return null;
}

export function createOrder(draft: OrderDraft, id = Date.now().toString(36)): Order {
  const room = draft.room.trim();
  const images = (draft.images ?? []).filter((src) => src.length > 0);
  return {
    id,
    title: draft.title.trim(),
    lv: draft.lv.trim() + (room ? `/${room}` : ''),
    qty: draft.qty,
    due: formatThaiDueDate(draft.due),
    note: draft.note.trim(),
    ...(images.length > 0 ? { images } : {}),
    contact: draft.contact.trim(),
    price: null,
    status: 'รอราคา',
  };
}

export function setOrderPrice(orders: Order[], id: string, rawPrice: string): Order[] | null {
  if (rawPrice.trim() === '') return null;
  const price = Math.round(Number(rawPrice));
  if (!Number.isFinite(price) || price < 0) return null;
  return orders.map((o) =>
    o.id === id
      ? {
          ...o,
          price,
          status: o.status === 'เสร็จแล้ว' ? 'เสร็จแล้ว' : 'เสนอราคาแล้ว',
        }
      : o
  );
}

export function confirmOrder(orders: Order[], id: string): Order[] {
  return orders.map((o) => (o.id === id ? { ...o, status: 'ยืนยันแล้ว' } : o));
}

export function completeOrder(orders: Order[], id: string): Order[] {
  return orders.map((o) => (o.id === id ? { ...o, status: 'เสร็จแล้ว' } : o));
}

export function payOrderFromWallet(orders: Order[], id: string): Order[] {
  return orders.map((o) => (o.id === id ? { ...o, paid: true } : o));
}

export function deleteOrder(orders: Order[], id: string): Order[] {
  return orders.filter((o) => o.id !== id);
}

export function getPendingBadgeCount(orders: Order[], isAdmin: boolean): number {
  const targetStatus = isAdmin ? 'รอราคา' : 'เสนอราคาแล้ว';
  return orders.filter((o) => o.status === targetStatus).length;
}

export function getConfirmedTotal(orders: Order[]): number {
  return orders
    .filter((o) => o.status === 'ยืนยันแล้ว' || o.status === 'เสร็จแล้ว')
    .reduce((sum, o) => sum + (o.price ?? 0), 0);
}

export function applyThemeToDocument(mode: ThemeMode, accent: string, doc?: Document): void {
  if (!doc) return;
  const root = doc.documentElement;
  if (mode === 'system') {
    root.removeAttribute('data-theme');
  } else {
    root.dataset.theme = mode;
  }
  root.style.setProperty('--accent', accent);
  const metaTheme = doc.querySelector('meta[name="theme-color"]');
  if (metaTheme) {
    const prefersLight =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-color-scheme: light)').matches;
    const isLight = mode === 'light' || (mode === 'system' && prefersLight);
    metaTheme.setAttribute('content', isLight ? '#ffffff' : '#131314');
  }
}
