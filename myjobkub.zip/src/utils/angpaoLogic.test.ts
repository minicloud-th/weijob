import test from 'node:test';
import assert from 'node:assert/strict';
import {
  extractVoucherHash,
  isValidThaiPhone,
  mapTrueMoneyStatusMessage,
  parseAngpaoApiResponse,
} from './angpaoLogic';

test('extractVoucherHash parses full Angpao URLs, voucher paths, and raw hashes', () => {
  assert.equal(
    extractVoucherHash('https://gift.truemoney.com/campaign/?v=01937abcdef12345678'),
    '01937abcdef12345678'
  );
  assert.equal(
    extractVoucherHash('https://gift.truemoney.com/campaign/vouchers/01937abcdef12345678'),
    '01937abcdef12345678'
  );
  assert.equal(extractVoucherHash('01937abcdef12345678'), '01937abcdef12345678');
  assert.equal(extractVoucherHash('invalid-short'), null);
  assert.equal(extractVoucherHash(''), null);
});

test('isValidThaiPhone validates standard 10-digit Thai mobile numbers', () => {
  assert.equal(isValidThaiPhone('0812345678'), true);
  assert.equal(isValidThaiPhone('091-234-5678'), true);
  assert.equal(isValidThaiPhone('0612345678'), true);
  assert.equal(isValidThaiPhone('12345'), false);
  assert.equal(isValidThaiPhone('0212345678'), false);
});

test('parseAngpaoApiResponse handles SUCCESS and TrueMoney error codes', () => {
  const ok = parseAngpaoApiResponse(
    {
      status: { code: 'SUCCESS', message: 'success' },
      data: {
        owner_profile: { full_name: 'สมชาย ใจดี' },
        my_ticket: { amount_baht: '150.00' },
      },
    },
    'hash1234567890',
    '0812345678'
  );
  assert.equal(ok.ok, true);
  if (ok.ok) {
    assert.equal(ok.amountBaht, 150);
    assert.equal(ok.ownerName, 'สมชาย ใจดี');
  }

  const expired = parseAngpaoApiResponse(
    { status: { code: 'VOUCHER_EXPIRED', message: 'voucher expired' } },
    'hash1234567890',
    '0812345678'
  );
  assert.equal(expired.ok, false);
  if (!expired.ok) {
    assert.equal(expired.code, 'VOUCHER_EXPIRED');
    assert.ok(expired.error.includes('หมดอายุ'));
  }

  assert.ok(mapTrueMoneyStatusMessage('VOUCHER_OUT_OF_STOCK').includes('เต็ม'));
});
