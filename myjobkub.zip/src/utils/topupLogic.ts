import type {
  GiftCodeItem,
  Order,
  TopUpChannel,
  TopUpRecord,
} from '../types/myjobkub';
import { EMBEDDED_LOGOS } from './embeddedLogos';

export interface BankItem {
  name: string;
  shortName: string;
  logo: string;
}

export const BANK_LIST: BankItem[] = [
  { name: 'กสิกรไทย (KBank)', shortName: 'กสิกรไทย', logo: EMBEDDED_LOGOS.KBANK },
  { name: 'ไทยพาณิชย์ (SCB)', shortName: 'ไทยพาณิชย์', logo: EMBEDDED_LOGOS.SCB },
  { name: 'กรุงไทย (KTB)', shortName: 'กรุงไทย', logo: EMBEDDED_LOGOS.KTB },
  { name: 'กรุงเทพ (BBL)', shortName: 'กรุงเทพ', logo: EMBEDDED_LOGOS.BBL },
  { name: 'กรุงศรีอยุธยา (BAY)', shortName: 'กรุงศรีอยุธยา', logo: EMBEDDED_LOGOS.BAY },
  { name: 'ทีทีบี (ttb)', shortName: 'ทีทีบี (ttb)', logo: EMBEDDED_LOGOS.TTB },
  { name: 'ออมสิน (GSB)', shortName: 'ออมสิน', logo: EMBEDDED_LOGOS.GSB },
  { name: 'ธ.ก.ส. (BAAC)', shortName: 'ธ.ก.ส.', logo: EMBEDDED_LOGOS.BAAC },
  { name: 'อาคารสงเคราะห์ (GHB)', shortName: 'ธ.อ.ส.', logo: EMBEDDED_LOGOS.GHB },
  { name: 'เกียรตินาคินภัทร (KKP)', shortName: 'เกียรตินาคินภัทร', logo: EMBEDDED_LOGOS.KKP },
  { name: 'ซีไอเอ็มบี ไทย (CIMB)', shortName: 'ซีไอเอ็มบี', logo: EMBEDDED_LOGOS.CIMB },
  { name: 'ยูโอบี (UOB)', shortName: 'ยูโอบี', logo: EMBEDDED_LOGOS.UOB },
  { name: 'ทิสโก้ (TISCO)', shortName: 'ทิสโก้', logo: EMBEDDED_LOGOS.TISCO },
  { name: 'แลนด์ แอนด์ เฮ้าส์ (LH Bank)', shortName: 'LH Bank', logo: EMBEDDED_LOGOS.LHB },
  { name: 'ไทยเครดิต (Thai Credit)', shortName: 'ไทยเครดิต', logo: EMBEDDED_LOGOS.TCRB },
  { name: 'ไอซีบีซี ไทย (ICBC)', shortName: 'ICBC', logo: EMBEDDED_LOGOS.ICBC },
  { name: 'อิสลามแห่งประเทศไทย (ibank)', shortName: 'อิสลาม (ibank)', logo: EMBEDDED_LOGOS.IBANK },
  { name: 'ซิตี้แบงก์ (Citibank)', shortName: 'Citibank', logo: EMBEDDED_LOGOS.CITI },
  { name: 'เอชเอสบีซี (HSBC)', shortName: 'HSBC', logo: EMBEDDED_LOGOS.HSBC },
  { name: 'พร้อมเพย์ (PromptPay)', shortName: 'พร้อมเพย์', logo: EMBEDDED_LOGOS.PromptPay },
];

export const BANK_OPTIONS: string[] = BANK_LIST.map((b) => b.name);

export function getBankLogo(bankName?: string): string {
  const found = BANK_LIST.find((b) => b.name === bankName);
  return found ? found.logo : EMBEDDED_LOGOS.PromptPay;
}

export const CASH_MEETUP_LOCATION = 'หน้าห้อง 226';

export const BANK_RECEIVER_ACCOUNT = {
  bankName: 'กสิกรไทย (KBank)',
  shortName: 'ธนาคารกสิกรไทย',
  accountNumber: '1963870325',
  accountName: 'กรวิชญ์',
  qrImage: '/assets/aistudio/Screenshot_2026-11-17_08.56.06_7856779e.png',
  logo: EMBEDDED_LOGOS.KBANK,
} as const;

export const DEFAULT_GIFT_CODES: GiftCodeItem[] = [
  { code: 'WEI50', amount: 50 },
  { code: 'WEI100', amount: 100 },
  { code: 'SRIMUANG200', amount: 200 },
];

export const TOPUP_CHANNELS: Array<{
  key: TopUpChannel;
  label: string;
  description: string;
  logo: string;
}> = [
  {
    key: 'truemoney',
    label: 'TRUE MONEY',
    description: 'เติมเงินผ่านลิงก์ซองอั่งเปา TrueMoney อัตโนมัติ',
    logo: EMBEDDED_LOGOS.TrueMoney,
  },
  {
    key: 'bank',
    label: 'ธนาคาร',
    description: 'รองรับทุกธนาคารไทย / พร้อมเพย์ แล้วแจ้งสลิป',
    logo: EMBEDDED_LOGOS.PromptPay,
  },
  {
    key: 'cash',
    label: 'เงินสด',
    description: 'นัดรับเฉพาะหน้าห้อง 226',
    logo: EMBEDDED_LOGOS.cash,
  },
  {
    key: 'giftcode',
    label: 'กิ๊ฟโค๊ด',
    description: 'กรอกรหัสโค้ดรับเครดิตเข้าวอลเล็ตทันที',
    logo: EMBEDDED_LOGOS.giftcode,
  },
];

export interface TopUpDraft {
  channel: TopUpChannel;
  amount: string;
  contact: string;
  walletPhone: string;
  reference: string;
  bankName: string;
  slipImage?: string;
  meetupLocation: string;
  note: string;
  giftCode: string;
}

export function getChannelMeta(channel: TopUpChannel) {
  return TOPUP_CHANNELS.find((c) => c.key === channel) ?? TOPUP_CHANNELS[0];
}

export function validateBankStepOne(amount: string, bankName: string): string | null {
  const parsedAmount = Number(amount);
  if (!amount.trim() || !Number.isFinite(parsedAmount) || parsedAmount <= 0) {
    return 'ใส่จำนวนเงินที่ต้องการเติมให้ถูกต้องนะ';
  }
  if (!bankName.trim()) {
    return 'เลือกธนาคารก่อนนะ';
  }
  return null;
}

export function validateTopUpDraft(draft: TopUpDraft): string | null {
  if (draft.channel === 'giftcode') {
    if (!draft.giftCode.trim()) return 'กรอกรหัสกิ๊ฟโค๊ดก่อนนะ';
    return null;
  }

  const parsedAmount = Number(draft.amount);
  if (!draft.amount.trim() || !Number.isFinite(parsedAmount) || parsedAmount <= 0) {
    return 'ใส่จำนวนเงินที่ต้องการเติมให้ถูกต้องนะ';
  }

  if (draft.channel === 'truemoney') {
    const phoneDigits = draft.walletPhone.replace(/\D/g, '');
    if (phoneDigits.length < 9) return 'ใส่เบอร์ TrueMoney Wallet ให้ครบนะ';
    if (!draft.reference.trim()) return 'ใส่เลขอ้างอิงหรือลิงก์ซองทรูมันนี่ด้วยนะ';
  } else if (draft.channel === 'bank') {
    if (!draft.bankName.trim()) return 'เลือกธนาคารก่อนนะ';
    if (!draft.slipImage?.trim()) return 'แนบสลิปโอนเงินก่อนส่งนะ';
  }

  return null;
}

export function redeemGiftCode(
  rawCode: string,
  giftCodes: GiftCodeItem[],
  usedGiftCodes: string[],
  contact: string,
  id = `top-${Date.now().toString(36)}`,
  createdAt = new Date().toISOString()
): { ok: true; record: TopUpRecord; normalizedCode: string } | { ok: false; error: string } {
  const code = rawCode.trim().toUpperCase();
  if (!code) return { ok: false, error: 'กรอกรหัสกิ๊ฟโค๊ดก่อนนะ' };
  if (usedGiftCodes.includes(code)) {
    return { ok: false, error: 'กิ๊ฟโค๊ดนี้ถูกใช้ไปแล้วนะ' };
  }
  const match = giftCodes.find((g) => g.code.toUpperCase() === code);
  if (!match) {
    return { ok: false, error: 'ไม่พบรหัสกิ๊ฟโค๊ดนี้ ลองเช็กตัวอักษรอีกครั้งนะ' };
  }

  return {
    ok: true,
    normalizedCode: code,
    record: {
      id,
      channel: 'giftcode',
      amount: match.amount,
      status: 'สำเร็จ',
      createdAt,
      contact: contact.trim(),
      giftCode: code,
    },
  };
}

export function createTopUpRecord(
  draft: TopUpDraft,
  id = `top-${Date.now().toString(36)}`,
  createdAt = new Date().toISOString()
): TopUpRecord {
  const amount = Math.round(Number(draft.amount));
  const base: TopUpRecord = {
    id,
    channel: draft.channel,
    amount,
    status: 'รอตรวจสอบ',
    createdAt,
    contact: draft.contact.trim(),
  };

  if (draft.channel === 'truemoney') {
    return {
      ...base,
      walletPhone: draft.walletPhone.trim(),
      reference: draft.reference.trim(),
    };
  }
  if (draft.channel === 'bank') {
    return {
      ...base,
      bankName: draft.bankName.trim(),
      ...(draft.slipImage?.trim() ? { slipImage: draft.slipImage.trim() } : {}),
    };
  }
  return {
    ...base,
    meetupLocation: CASH_MEETUP_LOCATION,
    note: draft.note.trim(),
  };
}

export function approveTopUp(topups: TopUpRecord[], id: string): TopUpRecord[] {
  return topups.map((t) => (t.id === id ? { ...t, status: 'สำเร็จ' } : t));
}

export function rejectTopUp(topups: TopUpRecord[], id: string): TopUpRecord[] {
  return topups.map((t) => (t.id === id ? { ...t, status: 'ไม่ผ่าน' } : t));
}

export function getWalletBalance(topups: TopUpRecord[], orders: Order[]): number {
  const credited = topups
    .filter((t) => t.status === 'สำเร็จ')
    .reduce((sum, t) => sum + t.amount, 0);
  const spent = orders
    .filter((o) => o.paid && typeof o.price === 'number')
    .reduce((sum, o) => sum + (o.price ?? 0), 0);
  return Math.max(0, credited - spent);
}

export function getPendingTopUpAmount(topups: TopUpRecord[]): number {
  return topups
    .filter((t) => t.status === 'รอตรวจสอบ')
    .reduce((sum, t) => sum + t.amount, 0);
}

export function getPendingTopUpCount(topups: TopUpRecord[]): number {
  return topups.filter((t) => t.status === 'รอตรวจสอบ').length;
}

export function normalizeTopUpRecord(raw: Record<string, unknown>): TopUpRecord | null {
  if (!raw || typeof raw.channel !== 'string') return null;
  const channel = raw.channel as TopUpChannel;
  if (!['truemoney', 'bank', 'cash', 'giftcode'].includes(channel)) return null;
  const status =
    raw.status === 'สำเร็จ' || raw.status === 'ไม่ผ่าน' || raw.status === 'รอตรวจสอบ'
      ? raw.status
      : 'รอตรวจสอบ';
  return {
    id: String(raw.id ?? Date.now().toString(36)),
    channel,
    amount: typeof raw.amount === 'number' && Number.isFinite(raw.amount) ? raw.amount : 0,
    status,
    createdAt: String(raw.createdAt ?? new Date().toISOString()),
    contact: String(raw.contact ?? ''),
    walletPhone: typeof raw.walletPhone === 'string' ? raw.walletPhone : undefined,
    reference: typeof raw.reference === 'string' ? raw.reference : undefined,
    bankName: typeof raw.bankName === 'string' ? raw.bankName : undefined,
    slipImage: typeof raw.slipImage === 'string' && raw.slipImage ? raw.slipImage : undefined,
    meetupLocation: typeof raw.meetupLocation === 'string' ? raw.meetupLocation : undefined,
    note: typeof raw.note === 'string' ? raw.note : undefined,
    giftCode: typeof raw.giftCode === 'string' ? raw.giftCode : undefined,
  };
}
