import test from 'node:test';
import assert from 'node:assert/strict';
import {
  isValidContact,
  formatBaht,
  validateOrderInput,
  createOrder,
  setOrderPrice,
  confirmOrder,
  completeOrder,
  deleteOrder,
  getPendingBadgeCount,
  getConfirmedTotal,
  loadAppState,
  saveAppState,
  normalizeOrder,
  WEI_VARIANTS,
  getNextWeiIndex,
  MAX_ORDER_IMAGES,
} from './myjobkubLogic';
import type { Order } from '../types/myjobkub';

test('isValidContact validates emails and phone numbers accurately', () => {
  assert.equal(isValidContact('student@srimuang.ac.th'), true);
  assert.equal(isValidContact('0812345678'), true);
  assert.equal(isValidContact('+66 81-234-5678'), true);
  assert.equal(isValidContact('123456'), false);
  assert.equal(isValidContact('not-an-email'), false);
  assert.equal(isValidContact('   '), false);
});

test('formatBaht formats currency with Baht sign and commas', () => {
  assert.equal(formatBaht(0), '฿0');
  assert.equal(formatBaht(150), '฿150');
  assert.equal(formatBaht(1250), '฿1,250');
});

test('validateOrderInput catches missing fields in exact order and restricts to ม.1–ม.3', () => {
  const base = {
    title: 'ใบงานฟิสิกส์',
    lv: 'ม.2',
    room: '2',
    qty: '5 แผ่น',
    due: '2026-12-01',
    note: 'ส่งครูสมชาย',
    contact: '0812345678',
    isStudent: true,
  };

  assert.equal(validateOrderInput(base), null);
  assert.equal(validateOrderInput({ ...base, title: '  ' })?.field, 'o1');
  assert.equal(validateOrderInput({ ...base, lv: '' })?.field, 'lv');
  assert.equal(validateOrderInput({ ...base, lv: 'ม.4' })?.field, 'lv');
  assert.equal(validateOrderInput({ ...base, due: '' })?.field, 'o4');
  assert.equal(validateOrderInput({ ...base, contact: '' })?.field, 'o6');
  assert.equal(validateOrderInput({ ...base, isStudent: false })?.field, 'o8');
});

test('order lifecycle transitions: create, quote, confirm, complete, delete', () => {
  const created = createOrder(
    {
      title: 'วาดรูปส่งครูศิลปะ',
      lv: 'ม.3',
      room: '1',
      qty: '1 ชิ้น',
      due: '2026-12-10',
      note: 'สีไม้',
      contact: '0899999999',
      isStudent: true,
    },
    'ord-1'
  );

  assert.equal(created.id, 'ord-1');
  assert.equal(created.lv, 'ม.3/1');
  assert.equal(created.status, 'รอราคา');
  assert.equal(created.price, null);

  let orders: Order[] = [created];
  assert.equal(getPendingBadgeCount(orders, true), 1);
  assert.equal(getPendingBadgeCount(orders, false), 0);

  // Invalid price returns null
  assert.equal(setOrderPrice(orders, 'ord-1', ''), null);
  assert.equal(setOrderPrice(orders, 'ord-1', '-10'), null);

  const quoted = setOrderPrice(orders, 'ord-1', '200');
  assert.ok(quoted);
  orders = quoted;
  assert.equal(orders[0].price, 200);
  assert.equal(orders[0].status, 'เสนอราคาแล้ว');
  assert.equal(getPendingBadgeCount(orders, true), 0);
  assert.equal(getPendingBadgeCount(orders, false), 1);
  assert.equal(getConfirmedTotal(orders), 0);

  orders = confirmOrder(orders, 'ord-1');
  assert.equal(orders[0].status, 'ยืนยันแล้ว');
  assert.equal(getConfirmedTotal(orders), 200);

  orders = completeOrder(orders, 'ord-1');
  assert.equal(orders[0].status, 'เสร็จแล้ว');
  assert.equal(getConfirmedTotal(orders), 200);

  // Quoting a completed order preserves เสร็จแล้ว status
  const reQuoted = setOrderPrice(orders, 'ord-1', '250');
  assert.ok(reQuoted);
  assert.equal(reQuoted[0].status, 'เสร็จแล้ว');
  assert.equal(reQuoted[0].price, 250);

  orders = deleteOrder(reQuoted, 'ord-1');
  assert.equal(orders.length, 0);
});

test('normalizeOrder upgrades legacy order records', () => {
  const legacy = normalizeOrder(
    { id: 'old1', t: 'การบ้าน', title: 'คณิต', lv: 'ม.2', q: 3, u: 'หน้า', due: '12 พ.ย.', note: '' },
    '0811112222'
  );
  assert.equal(legacy.title, 'การบ้าน: คณิต');
  assert.equal(legacy.qty, '3 หน้า');
  assert.equal(legacy.status, 'รอราคา');
  assert.equal(legacy.price, null);
  assert.equal(legacy.contact, '0811112222');
});

test('loadAppState and saveAppState round-trip via storage interface', () => {
  const mem = new Map<string, string>();
  const mockStorage = {
    getItem: (k: string) => mem.get(k) ?? null,
    setItem: (k: string, v: string) => {
      mem.set(k, v);
    },
  };

  const initial = loadAppState(mockStorage);
  assert.equal(initial.in, false);
  assert.equal(initial.pin, '1234');

  const updated = { ...initial, in: true, name: 'ต้นกล้า', contact: '0812345678' };
  saveAppState(updated, mockStorage);
  const reloaded = loadAppState(mockStorage);
  assert.equal(reloaded.in, true);
  assert.equal(reloaded.name, 'ต้นกล้า');
  assert.equal(reloaded.contact, '0812345678');
});

test('WEI_VARIANTS includes wei, Thai เหวย, and multiple languages with wrap-around index', () => {
  assert.ok(WEI_VARIANTS.length >= 5);
  assert.equal(WEI_VARIANTS[0].text, 'wei');
  assert.equal(WEI_VARIANTS[1].text, 'เหวย');
  assert.equal(getNextWeiIndex(0), 1);
  assert.equal(getNextWeiIndex(WEI_VARIANTS.length - 1), 0);
  assert.equal(getNextWeiIndex(0, 0), 0);
});

test('createOrder preserves attached detail images and loadAppState filters non-junior-high lv', () => {
  const order = createOrder(
    {
      title: 'ใบงานคณิต',
      lv: 'ม.1',
      room: '4',
      qty: '2 หน้า',
      due: '2026-12-15',
      note: 'ดูตามรูป',
      images: ['data:image/png;base64,abc'],
      contact: '0812345678',
      isStudent: true,
    },
    'ord-img'
  );
  assert.deepEqual(order.images, ['data:image/png;base64,abc']);

  const mem = new Map<string, string>();
  mem.set('mjk', JSON.stringify({ in: true, lv: 'ม.5', orders: [order] }));
  const loaded = loadAppState({
    getItem: (k: string) => mem.get(k) ?? null,
  });
  assert.equal(loaded.lv, '');
  assert.deepEqual(loaded.orders[0].images, ['data:image/png;base64,abc']);
  assert.equal(MAX_ORDER_IMAGES, 10);
});
