export interface AngpaoSuccessResult {
  ok: true;
  voucherHash: string;
  amountBaht: number;
  ownerName: string;
  mobile: string;
}

export interface AngpaoErrorResult {
  ok: false;
  code: string;
  error: string;
}

export type AngpaoRedeemResult = AngpaoSuccessResult | AngpaoErrorResult;

export function extractVoucherHash(input: string): string | null {
  const trimmed = input.trim();
  if (!trimmed) return null;

  const queryMatch = trimmed.match(/[?&]v=([a-zA-Z0-9]{10,})/);
  if (queryMatch?.[1]) {
    return queryMatch[1];
  }

  const pathMatch = trimmed.match(/\/vouchers\/([a-zA-Z0-9]{10,})/);
  if (pathMatch?.[1]) {
    return pathMatch[1];
  }

  if (/^[a-zA-Z0-9]{10,}$/.test(trimmed)) {
    return trimmed;
  }

  return null;
}

export function normalizeThaiPhone(input: string): string {
  return input.replace(/\D/g, '');
}

export function isValidThaiPhone(input: string): boolean {
  const digits = normalizeThaiPhone(input);
  return /^0[689]\d{8}$/.test(digits);
}

export function mapTrueMoneyStatusMessage(code: string, fallbackMessage?: string): string {
  switch (code) {
    case 'VOUCHER_NOT_FOUND':
      return 'ไม่พบซองอั่งเปานี้ กรุณาตรวจสอบลิงก์อีกครั้ง';
    case 'VOUCHER_EXPIRED':
      return 'ซองอั่งเปานี้หมดอายุแล้ว (เกิน 72 ชั่วโมง)';
    case 'VOUCHER_OUT_OF_STOCK':
      return 'ซองอั่งเปานี้ถูกกดรับครบเต็มจำนวนแล้ว';
    case 'CANNOT_GET_OWN_VOUCHER':
      return 'ไม่สามารถรับซองอั่งเปาของเบอร์ตัวเองได้';
    case 'CANNOT_GET_MORE_ONE':
      return 'เบอร์นี้ได้รับเงินจากซองอั่งเปานี้ไปแล้ว';
    case 'TARGET_USER_NOT_FOUND':
    case 'TARGET_USER_STATUS_INACTIVE':
      return 'เบอร์ปลายทางยังไม่ได้เปิดใช้งาน TrueMoney Wallet';
    case 'INTERNAL_ERROR':
      return 'ระบบ TrueMoney ขัดข้องชั่วคราว กรุณาลองใหม่อีกครั้ง';
    default:
      return fallbackMessage?.trim()
        ? `รับซองไม่สำเร็จ (${code}: ${fallbackMessage})`
        : 'รับซองอั่งเปาไม่สำเร็จ กรุณาตรวจสอบข้อมูลอีกครั้ง';
  }
}

export function parseAngpaoApiResponse(
  payload: unknown,
  voucherHash: string,
  mobile: string
): AngpaoRedeemResult {
  if (!payload || typeof payload !== 'object') {
    return {
      ok: false,
      code: 'INVALID_RESPONSE',
      error: 'ข้อมูลตอบกลับจาก TrueMoney ไม่ถูกต้อง',
    };
  }

  const raw = payload as Record<string, unknown>;
  const statusObj =
    raw.status && typeof raw.status === 'object' ? (raw.status as Record<string, unknown>) : null;
  const code = typeof statusObj?.code === 'string' ? statusObj.code : 'UNKNOWN_ERROR';
  const message = typeof statusObj?.message === 'string' ? statusObj.message : '';

  if (code !== 'SUCCESS') {
    return {
      ok: false,
      code,
      error: mapTrueMoneyStatusMessage(code, message),
    };
  }

  const dataObj =
    raw.data && typeof raw.data === 'object' ? (raw.data as Record<string, unknown>) : null;
  const myTicket =
    dataObj?.my_ticket && typeof dataObj.my_ticket === 'object'
      ? (dataObj.my_ticket as Record<string, unknown>)
      : null;
  const voucherObj =
    dataObj?.voucher && typeof dataObj.voucher === 'object'
      ? (dataObj.voucher as Record<string, unknown>)
      : null;
  const ownerObj =
    dataObj?.owner_profile && typeof dataObj.owner_profile === 'object'
      ? (dataObj.owner_profile as Record<string, unknown>)
      : null;

  const rawBaht = myTicket?.amount_baht ?? voucherObj?.amount_baht;
  const parsedBaht = Number(String(rawBaht ?? '').replace(/,/g, ''));

  if (!Number.isFinite(parsedBaht) || parsedBaht <= 0) {
    return {
      ok: false,
      code: 'INVALID_AMOUNT',
      error: 'ไม่พบยอดเงินในซองอั่งเปานี้',
    };
  }

  return {
    ok: true,
    voucherHash,
    amountBaht: Math.round(parsedBaht * 100) / 100,
    ownerName: typeof ownerObj?.full_name === 'string' ? ownerObj.full_name : '',
    mobile,
  };
}
