import { useEffect, useState, useRef, type FormEvent } from 'react';
import { BrandWaveIcon, LogoSquiggle } from './Icons';
import { MorphingWei } from './MorphingWei';
import { isValidContact } from '../utils/myjobkubLogic';

interface LoginViewProps {
  onLogin: (contact: string) => void;
}

export function LoginView({ onLogin }: LoginViewProps) {
  const [contact, setContact] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const valid = isValidContact(contact);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!valid) return;
    onLogin(contact.trim());
  };

  return (
    <main id="login" className="h-full flex flex-col px-5">
      <div className="py-[22px] px-1">
        <span className="inline-flex items-center gap-1.5 font-semibold text-[15px]">
          <BrandWaveIcon className="w-6 h-6" />
          weijob
        </span>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center pb-[8vh] text-center">
        <LogoSquiggle className="w-[76px] h-[76px] mb-[26px]" />

        <h1
          className="m-0 font-medium tracking-[-0.02em] leading-[1.3]"
          style={{ fontSize: 'clamp(30px, 6vw, 48px)', maxWidth: '14em', textWrap: 'balance' }}
        >
          ฝากงานไว้กับ <MorphingWei /> จบไว ไม่ต้องเครียด
        </h1>

        <p className="mt-11 mb-3.5 text-[15px]" style={{ color: 'var(--muted)' }}>
          เข้าระบบหรือสมัครเลย
        </p>

        <form className="w-full max-w-[460px]" onSubmit={handleSubmit}>
          <input
            ref={inputRef}
            id="who"
            className="mjk-field"
            type="text"
            value={contact}
            onChange={(e) => setContact(e.target.value)}
            placeholder="เบอร์โทรหรืออีเมล"
            autoComplete="username"
            aria-label="เบอร์โทรหรืออีเมล"
          />
          <p className="mt-2.5 mx-2 mb-4 text-xs" style={{ color: 'var(--muted)' }}>
            รับเฉพาะนักเรียน ม.ต้น โรงเรียนศรีเมืองวิทยาคารนะ เดี๋ยว wei ทักกลับทางช่องทางนี้
          </p>
          <button type="submit" className="mjk-primary" disabled={!valid}>
            ไปต่อเลย
          </button>
        </form>
      </div>
    </main>
  );
}
