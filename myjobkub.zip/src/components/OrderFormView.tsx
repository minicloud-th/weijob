import { useState, useRef, type ChangeEvent, type FormEvent } from 'react';
import { ChevronDown, ImagePlus, X } from 'lucide-react';
import type { OrderDraft } from '../types/myjobkub';
import {
  GRADES,
  MAX_ORDER_IMAGES,
  getTodayIsoDate,
  validateOrderInput,
} from '../utils/myjobkubLogic';
import { compressImageToDataUrl } from '../utils/imageUpload';

interface OrderFormViewProps {
  selectedLevel: string;
  defaultContact: string;
  onSelectLevel: (lv: string) => void;
  onSubmitOrder: (draft: OrderDraft) => void;
}

export function OrderFormView({
  selectedLevel,
  defaultContact,
  onSelectLevel,
  onSubmitOrder,
}: OrderFormViewProps) {
  const [title, setTitle] = useState('');
  const [room, setRoom] = useState('');
  const [qty, setQty] = useState('');
  const [due, setDue] = useState('');
  const [note, setNote] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [contact, setContact] = useState(defaultContact);
  const [isStudent, setIsStudent] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const o1Ref = useRef<HTMLInputElement>(null);
  const lvRef = useRef<HTMLSelectElement>(null);
  const o4Ref = useRef<HTMLInputElement>(null);
  const o6Ref = useRef<HTMLInputElement>(null);
  const o8Ref = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const minDate = getTodayIsoDate();

  const handleImageChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;

    const remaining = Math.max(0, MAX_ORDER_IMAGES - images.length);
    const selectedFiles = Array.from(fileList)
      .filter((f) => f.type.startsWith('image/'))
      .slice(0, remaining);

    if (selectedFiles.length === 0) {
      e.target.value = '';
      return;
    }

    setUploading(true);
    try {
      const encoded = await Promise.all(selectedFiles.map((f) => compressImageToDataUrl(f)));
      setImages((prev) => [...prev, ...encoded].slice(0, MAX_ORDER_IMAGES));
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleRemoveImage = (idx: number) => {
    setImages((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const draft: OrderDraft = {
      title,
      lv: selectedLevel,
      room,
      qty,
      due,
      note,
      images,
      contact,
      isStudent,
    };
    const err = validateOrderInput(draft);
    if (err) {
      setErrorMsg(err.message);
      if (err.field === 'o1') o1Ref.current?.focus();
      else if (err.field === 'lv') lvRef.current?.focus();
      else if (err.field === 'o4') o4Ref.current?.focus();
      else if (err.field === 'o6') o6Ref.current?.focus();
      else if (err.field === 'o8') o8Ref.current?.focus();
      return;
    }
    setErrorMsg('');
    onSubmitOrder(draft);
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      <p className="mt-0 mb-[22px]" style={{ color: 'var(--muted)' }}>
        รับงานเฉพาะนักเรียน ม.ต้น (ม.1–ม.3) พิมพ์หรือแนบรูปงานได้เลย ยิ่งละเอียดยิ่งได้ราคาตรง
      </p>

      <input
        ref={o1Ref}
        id="o1"
        className="mjk-field mt-2.5"
        maxLength={120}
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="งานที่ต้องการ เช่น ใบงานวิทย์ หรือวาดรูปส่งครูศิลปะ"
        aria-label="งานที่ต้องการ เช่น ใบงานวิทย์ หรือวาดรูปส่งครูศิลปะ"
      />

      <label
        htmlFor="lv-select"
        className="block mt-6 mb-2 text-[13px]"
        style={{ color: 'var(--muted)' }}
      >
        ชั้นอะไร (เฉพาะ ม.ต้น)
      </label>
      <div className="relative">
        <select
          ref={lvRef}
          id="lv-select"
          value={selectedLevel}
          onChange={(e) => onSelectLevel(e.target.value)}
          aria-label="ชั้นอะไร"
          className="mjk-field appearance-none pr-11 cursor-pointer"
          style={{
            color: selectedLevel ? 'var(--text)' : 'var(--muted)',
          }}
        >
          <option value="">เลือกชั้น ม.ต้น (ม.1–ม.3)</option>
          {GRADES.map((grade) => (
            <option key={grade} value={grade} style={{ color: 'var(--text)', background: 'var(--card)' }}>
              {grade}
            </option>
          ))}
        </select>
        <ChevronDown
          className="w-4 h-4 pointer-events-none absolute right-4 top-1/2 -translate-y-1/2"
          style={{ color: 'var(--muted)' }}
          aria-hidden="true"
        />
      </div>

      <input
        id="o7"
        className="mjk-field mt-2.5"
        maxLength={120}
        value={room}
        onChange={(e) => setRoom(e.target.value)}
        placeholder="ห้อง เช่น 3"
        aria-label="ห้อง เช่น 3"
      />

      <input
        id="o3"
        className="mjk-field mt-2.5"
        maxLength={120}
        value={qty}
        onChange={(e) => setQty(e.target.value)}
        placeholder="จำนวนงาน เช่น 5 แผ่น"
        aria-label="จำนวนงาน เช่น 5 แผ่น"
      />

      <div className="mt-6 mb-2 text-[13px]" style={{ color: 'var(--muted)' }}>
        ต้องส่งวันไหน
      </div>
      <input
        ref={o4Ref}
        id="o4"
        className="mjk-field"
        type="date"
        min={minDate}
        value={due}
        onChange={(e) => setDue(e.target.value)}
        aria-label="ส่งภายในวันที่"
      />

      <textarea
        id="o5"
        className="mjk-field mt-2.5"
        rows={3}
        maxLength={500}
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="บอกรายละเอียดเพิ่มได้ เช่น ครูสั่งอะไรมา"
        aria-label="รายละเอียดเพิ่มเติม"
      />

      <div className="mt-6 mb-2 text-[13px]" style={{ color: 'var(--muted)' }}>
        รูปรายละเอียด (สูงสุด {MAX_ORDER_IMAGES} รูป)
      </div>
      <div
        className="rounded-[18px] p-3.5"
        style={{ background: 'var(--card)' }}
      >
        <input
          ref={fileInputRef}
          id="o-images"
          type="file"
          accept="image/*"
          multiple
          onChange={handleImageChange}
          aria-label="แนบรูปรายละเอียด"
          className="sr-only"
        />

        {images.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 mb-3">
            {images.map((src, idx) => (
              <div
                key={`${idx}-${src.slice(0, 24)}`}
                className="relative aspect-square rounded-xl overflow-hidden"
                style={{ background: 'var(--card2)' }}
              >
                <img
                  src={src}
                  alt={`รูปรายละเอียด ${idx + 1}`}
                  className="w-full h-full object-cover"
                />
                <button
                  type="button"
                  onClick={() => handleRemoveImage(idx)}
                  aria-label={`ลบรูปที่ ${idx + 1}`}
                  className="absolute top-1.5 right-1.5 w-7 h-7 rounded-full grid place-items-center bg-black/70 text-white hover:bg-black/90 transition-colors"
                >
                  <X className="w-3.5 h-3.5" aria-hidden="true" />
                </button>
              </div>
            ))}
          </div>
        ) : null}

        <button
          type="button"
          disabled={uploading || images.length >= MAX_ORDER_IMAGES}
          onClick={() => fileInputRef.current?.click()}
          className="w-full min-h-[44px] px-4 py-2.5 rounded-xl flex items-center justify-center gap-2 text-[14px] font-medium transition-colors disabled:opacity-45"
          style={{ background: 'var(--card2)', color: 'var(--text)' }}
        >
          <ImagePlus className="w-[18px] h-[18px]" aria-hidden="true" />
          <span>
            {uploading
              ? 'กำลังประมวลผลรูป...'
              : images.length >= MAX_ORDER_IMAGES
                ? `แนบครบ ${MAX_ORDER_IMAGES} รูปแล้ว`
                : images.length > 0
                  ? `เพิ่มรูปรายละเอียด (${images.length}/${MAX_ORDER_IMAGES})`
                  : 'แนบรูปรายละเอียด'}
          </span>
        </button>
      </div>

      <input
        ref={o6Ref}
        id="o6"
        className="mjk-field mt-2.5"
        maxLength={120}
        value={contact}
        onChange={(e) => setContact(e.target.value)}
        placeholder="เบอร์หรืออีเมลให้ wei ทักกลับ"
        aria-label="เบอร์หรืออีเมลให้ wei ทักกลับ"
      />

      <label className="flex gap-2.5 items-center mt-3.5 mx-1 text-[14px] cursor-pointer">
        <input
          ref={o8Ref}
          id="o8"
          type="checkbox"
          checked={isStudent}
          onChange={(e) => setIsStudent(e.target.checked)}
          className="w-5 h-5"
          style={{ accentColor: 'var(--accent)' }}
        />
        <span>เป็นนักเรียน ม.ต้น โรงเรียนศรีเมืองวิทยาคาร</span>
      </label>

      <p className="mt-3.5 mx-1 mb-3 text-[14px]" style={{ color: 'var(--muted)' }}>
        ส่งแล้วรอแอดมินบอกราคาก่อนนะ
      </p>

      {errorMsg ? (
        <p id="err" role="alert" className="mt-2.5 mx-1 mb-2 text-[13.5px] text-[#ff6b6b]">
          {errorMsg}
        </p>
      ) : null}

      <button type="submit" className="mjk-primary mt-1">
        ส่งงานเลย
      </button>
    </form>
  );
}
