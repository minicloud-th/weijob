import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { getNextWeiIndex, WEI_VARIANTS } from '../utils/myjobkubLogic';

interface MorphingWeiProps {
  intervalMs?: number;
  className?: string;
}

export function MorphingWei({ intervalMs = 2400, className = '' }: MorphingWeiProps) {
  const [state, setState] = useState<{ current: number; previous: number | null; tick: number }>({
    current: 0,
    previous: null,
    tick: 0,
  });
  const [reducedMotion, setReducedMotion] = useState(false);
  const [boxWidth, setBoxWidth] = useState<number | null>(null);
  const measureRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mq.matches);
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  useEffect(() => {
    if (reducedMotion) return;
    let clearPrevTimer: number | undefined;
    const cycleTimer = window.setInterval(() => {
      setState((prev) => ({
        current: getNextWeiIndex(prev.current),
        previous: prev.current,
        tick: prev.tick + 1,
      }));
      clearPrevTimer = window.setTimeout(() => {
        setState((prev) => ({ ...prev, previous: null }));
      }, 540);
    }, intervalMs);

    return () => {
      window.clearInterval(cycleTimer);
      if (clearPrevTimer !== undefined) window.clearTimeout(clearPrevTimer);
    };
  }, [intervalMs, reducedMotion]);

  const currentItem = WEI_VARIANTS[state.current] ?? WEI_VARIANTS[0];
  const prevItem = state.previous !== null ? WEI_VARIANTS[state.previous] : null;
  const isLatin = (lang: string) => lang === 'en' || lang === 'vi';

  useLayoutEffect(() => {
    const el = measureRef.current;
    if (!el) return;
    const w = Math.ceil(el.getBoundingClientRect().width);
    if (w > 0) setBoxWidth(w);
  }, [state.current]);

  return (
    <span
      className={`inline-grid place-items-center relative align-baseline mx-1.5 ${className}`}
      style={{
        fontFamily:
          '"Shantell Sans", "Playpen Sans Thai", "Yusei Magic", "Gamja Flower", cursive',
        fontSize: '1.08em',
        fontWeight: 500,
        lineHeight: 1.15,
        color: 'inherit',
        width: boxWidth ? `${boxWidth}px` : undefined,
        transition: reducedMotion ? 'none' : 'width 460ms cubic-bezier(0.22, 1, 0.36, 1)',
      }}
      aria-live="off"
      data-testid="morphing-wei"
    >
      {/* Hidden sizer for exact smooth width interpolation */}
      <span
        ref={measureRef}
        aria-hidden="true"
        className="invisible pointer-events-none whitespace-nowrap col-start-1 row-start-1 px-0.5"
        style={{ fontStyle: isLatin(currentItem.lang) ? 'italic' : 'normal' }}
      >
        {currentItem.text}
      </span>

      {prevItem && !reducedMotion ? (
        <span
          key={`out-${state.tick}-${prevItem.text}`}
          aria-hidden="true"
          lang={prevItem.lang}
          className="col-start-1 row-start-1 whitespace-nowrap pointer-events-none wei-cross-out"
          style={{ fontStyle: isLatin(prevItem.lang) ? 'italic' : 'normal' }}
        >
          {prevItem.text}
        </span>
      ) : null}

      <span
        key={`in-${state.tick}-${currentItem.text}`}
        lang={currentItem.lang}
        className={`col-start-1 row-start-1 whitespace-nowrap ${
          reducedMotion || state.tick === 0 ? '' : 'wei-cross-in'
        }`}
        style={{ fontStyle: isLatin(currentItem.lang) ? 'italic' : 'normal' }}
      >
        {currentItem.text}
      </span>
    </span>
  );
}
