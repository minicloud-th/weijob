import type { ReactNode } from 'react';
import type { PageKey } from '../types/myjobkub';
import { CheckIcon, HomeIcon, PlusIcon, SettingsIcon, WalletIcon } from './Icons';

interface NavRailProps {
  currentPage: PageKey;
  badgeCount: number;
  topupBadgeCount: number;
  onNavigate: (page: PageKey) => void;
}

const MAIN_ITEMS: Array<{ key: PageKey; icon: ReactNode }> = [
  { key: 'หน้าหลัก', icon: <HomeIcon /> },
  { key: 'สั่งงาน', icon: <PlusIcon /> },
  { key: 'งานของฉัน', icon: <CheckIcon /> },
  { key: 'เติมเงิน', icon: <WalletIcon /> },
];

export function NavRail({
  currentPage,
  badgeCount,
  topupBadgeCount,
  onNavigate,
}: NavRailProps) {
  return (
    <nav
      className="mjk-rail flex flex-col items-center pb-3.5 overflow-y-auto shrink-0"
      style={{ borderRight: '1px solid var(--line)' }}
      aria-label="เมนู"
    >
      <div className="my-auto flex flex-col gap-3">
        {MAIN_ITEMS.map(({ key, icon }) => {
          const active = currentPage === key;
          const badge =
            key === 'งานของฉัน'
              ? badgeCount
              : key === 'เติมเงิน'
                ? topupBadgeCount
                : 0;
          return (
            <button
              key={key}
              type="button"
              title={key}
              aria-label={key}
              aria-current={active ? 'page' : undefined}
              onClick={() => onNavigate(key)}
              className="mjk-rb relative rounded-full grid place-items-center flex-none transition-colors"
              style={{
                background: active ? 'var(--card)' : 'transparent',
                color: active ? 'var(--text)' : 'var(--muted)',
              }}
            >
              {icon}
              {badge > 0 ? (
                <span
                  className="absolute top-0 right-0 min-w-[16px] h-4 px-1 rounded-lg text-[10px] font-bold grid place-items-center tabular-nums"
                  style={{ background: 'var(--accent)', color: 'var(--on)' }}
                >
                  {badge}
                </span>
              ) : null}
            </button>
          );
        })}
      </div>

      <button
        type="button"
        title="ตั้งค่า"
        aria-label="ตั้งค่า"
        aria-current={currentPage === 'ตั้งค่า' ? 'page' : undefined}
        onClick={() => onNavigate('ตั้งค่า')}
        className="mjk-rb relative rounded-full grid place-items-center flex-none transition-colors"
        style={{
          background: currentPage === 'ตั้งค่า' ? 'var(--card)' : 'transparent',
          color: currentPage === 'ตั้งค่า' ? 'var(--text)' : 'var(--muted)',
        }}
      >
        <SettingsIcon />
      </button>
    </nav>
  );
}
