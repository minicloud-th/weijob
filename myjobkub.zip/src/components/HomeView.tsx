import { MorphingWei } from './MorphingWei';

interface HomeViewProps {
  name: string;
  onOrderClick: () => void;
}

const STEPS = [
  'บอกว่าอยากได้งานอะไร ส่งวันไหน',
  'wei ดูงานแล้วบอกราคา',
  'โอเคก็กดตกลง แล้วรอรับงานเลย',
];

export function HomeView({ name, onOrderClick }: HomeViewProps) {
  const trimmedName = name.trim();
  return (
    <div>
      <div className="flex flex-col items-center text-center mt-6 mb-7">
        <h2
          className="m-0 font-medium leading-[1.3] tracking-[-0.01em]"
          style={{ fontSize: 'clamp(28px, 6vw, 40px)', textWrap: 'balance' }}
        >
          {trimmedName ? (
            `ว่าไง ${trimmedName}`
          ) : (
            <>
              ฝากงานไว้กับ <MorphingWei /> จบไว ไม่ต้องเครียด
            </>
          )}
        </h2>
        <p className="mt-2.5 mb-5 max-w-[26em]" style={{ color: 'var(--muted)' }}>
          ใบงาน การบ้าน วาดรูป หรืองานอะไรก็ได้ บอกมาเลย เดี๋ยว wei บอกราคาให้
          รับเฉพาะนักเรียน ม.ต้น โรงเรียนศรีเมืองวิทยาคาร
        </p>
        <button
          type="button"
          className="mjk-primary"
          style={{ width: 'min(280px, 100%)' }}
          onClick={onOrderClick}
        >
          สั่งงาน
        </button>
      </div>

      <div className="mt-6 mb-2 text-[13px]" style={{ color: 'var(--muted)' }}>
        ทำยังไงบ้าง
      </div>

      {STEPS.map((text, index) => (
        <div key={text} className="flex gap-3.5 items-center py-3 px-1">
          <span
            className="w-7 h-7 rounded-full grid place-items-center text-[13px] font-semibold flex-none tabular-nums"
            style={{ background: 'var(--card)' }}
          >
            {index + 1}
          </span>
          <span>{text}</span>
        </div>
      ))}
    </div>
  );
}
