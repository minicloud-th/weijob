import { useId } from 'react';

interface IconProps {
  className?: string;
}

export function BrandWaveIcon({ className = 'w-6 h-6' }: IconProps) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M3 12c0-3 2-5 4.5-5 4 0 5 10 9 10 2.5 0 4.5-2 4.5-5s-2-5-4.5-5c-4 0-5 10-9 10C5 17 3 15 3 12z" />
    </svg>
  );
}

export function LogoSquiggle({ className = 'w-[76px] h-[76px]' }: IconProps) {
  const gradId = useId();
  return (
    <svg
      className={className}
      viewBox="0 0 64 64"
      fill="none"
      stroke={`url(#${gradId})`}
      strokeWidth={8.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={gradId} x1="0" y1="1" x2="1" y2="0">
          <stop offset="0" stopColor="#1b55e6" />
          <stop offset="1" stopColor="#3f86ff" />
        </linearGradient>
      </defs>
      <path d="M8 20c3 22 8 28 13 28 6 0 7-22 11-22 5 0 6 22 12 22 6 0 10-14 12-28" />
    </svg>
  );
}

export function HomeIcon() {
  return (
    <svg
      className="w-5 h-5 flex-none"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M3 11 12 3l9 8M5 10v10h5v-6h4v6h5V10" />
    </svg>
  );
}

export function PlusIcon() {
  return (
    <svg
      className="w-5 h-5 flex-none"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M12 5v14M5 12h14" />
    </svg>
  );
}

export function CheckIcon() {
  return (
    <svg
      className="w-5 h-5 flex-none"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="m9 11 3 3L22 4M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
    </svg>
  );
}

export function SettingsIcon() {
  return (
    <svg
      className="w-5 h-5 flex-none"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6" />
    </svg>
  );
}

export function WalletIcon() {
  return (
    <svg
      className="w-5 h-5 flex-none"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M19 7V5a2 2 0 0 0-2-2H5a2 2 0 0 0 0 4h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5" />
      <path d="M16 14h4" />
    </svg>
  );
}
