import { useEffect, useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import { createPortal } from 'react-dom';
import { ArrowLeft, Check, ChevronDown, ChevronRight, Copy, ImagePlus, X } from 'lucide-react';
import type {
  GiftCodeItem,
  TopUpChannel,
  TopUpRecord,
} from '../types/myjobkub';
import { formatBaht } from '../utils/myjobkubLogic';
import { compressImageToDataUrl } from '../utils/imageUpload';
import { extractVoucherHash } from '../utils/angpaoLogic';
import {
  BANK_LIST,
  BANK_OPTIONS,
  BANK_RECEIVER_ACCOUNT,
  CASH_MEETUP_LOCATION,
  TOPUP_CHANNELS,
  getBankLogo,
  getChannelMeta,
  getPendingTopUpAmount,
  validateBankStepOne,
  validateTopUpDraft,
  type TopUpDraft,
} from '../utils/topupLogic';

interface TopUpViewProps {
  contact: string;
  walletBalance: number;
  topups: TopUpRecord[];
  giftCodes: GiftCodeItem[];
  usedGiftCodes: string[];
  isAdmin: boolean;
  onSubmitTopUp: (draft: TopUpDraft) => void;
  onRedeemAngpao: (
    voucherUrl: string
  ) => Promise<{ ok: true; amount: number; ownerName: string } | { ok: false; error: string }>;
  onRedeemGiftCode: (rawCode: string) => { ok: true; amount: number } | { ok: false; error: string };
  onApproveTopUp: (id: string) => void;
  onRejectTopUp: (id: string) => void;
  onAddGiftCode: (code: string, amount: number) => void;
}

export function TopUpView({
  contact,
  walletBalance,
  topups,
  giftCodes,
  usedGiftCodes,
  isAdmin,
  onSubmitTopUp,
  onRedeemAngpao,
  onRedeemGiftCode,
  onApproveTopUp,
  onRejectTopUp,
  onAddGiftCode,
}: TopUpViewProps) {
  const [activeChannel, setActiveChannel] = useState<TopUpChannel | null>(null);
  const [amount, setAmount] = useState('');
  const [reference, setReference] = useState('');
  const [angpaoLoading, setAngpaoLoading] = useState(false);

  const [bankName, setBankName] = useState(BANK_OPTIONS[0]);
  const [bankMenuOpen, setBankMenuOpen] = useState(false);
  const [bankStep, setBankStep] = useState<1 | 2>(1);
  const [slipImage, setSlipImage] = useState('');
  const [slipUploading, setSlipUploading] = useState(false);
  const [copiedAccount, setCopiedAccount] = useState(false);
  const [previewSlip, setPreviewSlip] = useState<string | null>(null);
  const bankDropdownRef = useRef<HTMLDivElement>(null);
  const slipInputRef = useRef<HTMLInputElement>(null);

  const [note, setNote] = useState('');
  const [giftCode, setGiftCode] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [statusMsg, setStatusMsg] = useState('');

  const [newCode, setNewCode] = useState('');
  const [newCodeAmount, setNewCodeAmount] = useState('');

  const pendingAmount = getPendingTopUpAmount(topups);

  useEffect(() => {
    if (!bankMenuOpen) return;
    const handleOutside = (event: MouseEvent) => {
      if (bankDropdownRef.current && !bankDropdownRef.current.contains(event.target as Node)) {
        setBankMenuOpen(false);
      }
    };
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setBankMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('mousedown', handleOutside);
      document.removeEventListener('keydown', handleKey);
    };
  }, [bankMenuOpen]);

  useEffect(() => {
    if (!previewSlip) return;
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setPreviewSlip(null);
      }
    };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [previewSlip]);

  const openChannel = (ch: TopUpChannel) => {
    setActiveChannel(ch);
    setBankMenuOpen(false);
    setBankStep(1);
    setSlipImage('');
    setCopiedAccount(false);
    setErrorMsg('');
    setStatusMsg('');
  };

  const backToCards = () => {
    setActiveChannel(null);
    setBankMenuOpen(false);
    setBankStep(1);
    setSlipImage('');
    setCopiedAccount(false);
    setErrorMsg('');
    setStatusMsg('');
  };

  const handleBankNext = () => {
    setStatusMsg('');
    const err = validateBankStepOne(amount, bankName);
    if (err) {
      setErrorMsg(err);
      return;
    }
    setErrorMsg('');
    setBankMenuOpen(false);
    setBankStep(2);
  };

  const handleSlipChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !file.type.startsWith('image/')) {
      e.target.value = '';
      return;
    }
    setSlipUploading(true);
    try {
      const encoded = await compressImageToDataUrl(file, 1000, 0.78);
      setSlipImage(encoded);
      setErrorMsg('');
    } finally {
      setSlipUploading(false);
      e.target.value = '';
    }
  };

  const handleCopyAccount = async () => {
    try {
      await navigator.clipboard.writeText(BANK_RECEIVER_ACCOUNT.accountNumber);
      setCopiedAccount(true);
      window.setTimeout(() => setCopiedAccount(false), 1800);
    } catch {
      // Clipboard API unavailable
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!activeChannel || angpaoLoading || slipUploading) return;
    setStatusMsg('');

    if (activeChannel === 'bank' && bankStep === 1) {
      handleBankNext();
      return;
    }

    if (activeChannel === 'giftcode') {
      const res = onRedeemGiftCode(giftCode);
      if (!res.ok) {
        setErrorMsg(res.error);
        return;
      }
      setErrorMsg('');
      setGiftCode('');
      setStatusMsg(`เติมเงินจากกิ๊ฟโค๊ดสำเร็จ +${formatBaht(res.amount)}`);
      return;
    }

    if (activeChannel === 'truemoney') {
      const hash = extractVoucherHash(reference);
      if (!hash) {
        setErrorMsg(
          'กรุณาวางลิงก์ซองอั่งเปา TrueMoney ให้ถูกต้อง เช่น https://gift.truemoney.com/campaign/?v=...'
        );
        return;
      }

      setErrorMsg('');
      setAngpaoLoading(true);
      const res = await onRedeemAngpao(reference);
      setAngpaoLoading(false);

      if (!res.ok) {
        setErrorMsg(res.error);
        return;
      }

      setReference('');
      setStatusMsg(
        `รับซองอั่งเปาสำเร็จ +${formatBaht(res.amount)}${res.ownerName ? ` (จาก ${res.ownerName})` : ''}`
      );
      return;
    }

    const draft: TopUpDraft = {
      channel: activeChannel,
      amount,
      contact,
      walletPhone: '',
      reference: activeChannel === 'bank' ? '' : reference,
      bankName,
      slipImage: activeChannel === 'bank' ? slipImage : undefined,
      meetupLocation: CASH_MEETUP_LOCATION,
      note,
      giftCode: '',
    };

    const err = validateTopUpDraft(draft);
    if (err) {
      setErrorMsg(err);
      return;
    }

    setErrorMsg('');
    const submittedAmount = Math.round(Number(amount));
    onSubmitTopUp(draft);
    setAmount('');
    setReference('');
    setSlipImage('');
    setBankStep(1);
    setNote('');
    setStatusMsg(
      activeChannel === 'bank'
        ? `ส่งสลิปเติมเงิน ${formatBaht(submittedAmount)} ผ่าน ${getChannelMeta(activeChannel).label} แล้ว รอแอดมินตรวจสอบ`
        : `ส่งคำขอเติมเงิน ${formatBaht(submittedAmount)} ผ่าน ${getChannelMeta(activeChannel).label} แล้ว รอแอดมินตรวจสอบ`
    );
  };

  const handleCreateGiftCode = () => {
    const cleanCode = newCode.trim().toUpperCase();
    const num = Math.round(Number(newCodeAmount));
    if (!cleanCode || !Number.isFinite(num) || num <= 0) return;
    onAddGiftCode(cleanCode, num);
    setNewCode('');
    setNewCodeAmount('');
  };

  const formatRecordDetail = (rec: TopUpRecord): string => {
    if (rec.channel === 'truemoney') {
      return `ซองอั่งเปา ${rec.reference ?? '-'}`;
    }
    if (rec.channel === 'bank') {
      return `${rec.bankName ?? '-'}${rec.reference ? ` · Ref ${rec.reference}` : ''}`;
    }
    if (rec.channel === 'cash') {
      return `จุดนัด: ${rec.meetupLocation ?? '-'}${rec.note ? ` · ${rec.note}` : ''}`;
    }
    return `โค้ด ${rec.giftCode ?? '-'}`;
  };

  const renderHistoryList = (items: TopUpRecord[], emptyText: string) => {
    if (items.length === 0) {
      return (
        <p className="my-4 mx-0.5" style={{ color: 'var(--muted)' }}>
          {emptyText}
        </p>
      );
    }

    return (
      <div className="space-y-2.5">
        {items.map((rec) => {
          const meta = getChannelMeta(rec.channel);
          const logoSrc = rec.channel === 'bank' ? getBankLogo(rec.bankName) : meta.logo;
          const logoAlt = rec.channel === 'bank' ? rec.bankName ?? meta.label : meta.label;
          return (
            <div
              key={rec.id}
              className="rounded-[18px] py-3.5 px-[18px]"
              style={{ background: 'var(--card)' }}
            >
              <div className="flex items-center gap-3">
                <img
                  src={logoSrc}
                  alt={logoAlt}
                  className="w-9 h-9 rounded-full object-cover shrink-0 bg-white"
                  style={{ border: '1px solid var(--line)' }}
                />
                <div className="min-w-0">
                  <b className="font-medium block tabular-nums">
                    {meta.label} · {formatBaht(rec.amount)}
                  </b>
                  <small className="block text-[13px] truncate" style={{ color: 'var(--muted)' }}>
                    {formatRecordDetail(rec)}
                  </small>
                  <small className="block text-[12px] tabular-nums" style={{ color: 'var(--muted)' }}>
                    {new Date(rec.createdAt).toLocaleString('th-TH', {
                      day: 'numeric',
                      month: 'short',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </small>
                </div>
                <span
                  className="ml-auto text-[13px] whitespace-nowrap shrink-0"
                  style={{
                    color:
                      rec.status === 'สำเร็จ'
                        ? 'var(--accent)'
                        : rec.status === 'ไม่ผ่าน'
                          ? '#ff6b6b'
                          : 'var(--muted)',
                  }}
                >
                  {rec.status}
                </span>
              </div>

              {rec.slipImage ? (
                <div className="mt-3 pl-12">
                  <button
                    type="button"
                    onClick={() => setPreviewSlip(rec.slipImage ?? null)}
                    aria-label={`ดูสลิปเติมเงิน ${rec.id}`}
                    className="inline-flex items-center gap-2.5 rounded-xl p-1.5 pr-3 text-[12.5px] transition-colors"
                    style={{ background: 'var(--card2)', color: 'var(--text)' }}
                  >
                    <img
                      src={rec.slipImage}
                      alt={`สลิปโอนเงิน ${rec.bankName ?? ''}`}
                      className="w-10 h-10 rounded-lg object-cover shrink-0"
                    />
                    <span>ดูสลิปโอนเงิน</span>
                  </button>
                </div>
              ) : null}

              {isAdmin && rec.status === 'รอตรวจสอบ' ? (
                <div className="flex gap-2 mt-3">
                  <button
                    type="button"
                    className="mjk-sm on"
                    style={{ padding: '8px 14px' }}
                    aria-label={`อนุมัติเติมเงิน ${rec.id}`}
                    onClick={() => onApproveTopUp(rec.id)}
                  >
                    อนุมัติ
                  </button>
                  <button
                    type="button"
                    className="mjk-sm"
                    style={{ padding: '8px 14px' }}
                    aria-label={`ปฏิเสธเติมเงิน ${rec.id}`}
                    onClick={() => onRejectTopUp(rec.id)}
                  >
                    ไม่ผ่าน
                  </button>
                </div>
              ) : null}
            </div>
          );
        })}
      </div>
    );
  };

  if (activeChannel) {
    const channelMeta = getChannelMeta(activeChannel);
    const channelRecords = topups.filter((t) => t.channel === activeChannel);
    const activeHeaderLogo =
      activeChannel === 'bank' ? getBankLogo(bankName) : channelMeta.logo;
    const selectedBank = BANK_LIST.find((b) => b.name === bankName) ?? BANK_LIST[0];

    return (
      <div className="mjk-page-enter" key={activeChannel}>
        <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
          <button
            type="button"
            onClick={backToCards}
            className="mjk-sm inline-flex items-center gap-1.5"
            style={{ padding: '8px 14px' }}
          >
            <ArrowLeft className="w-4 h-4" aria-hidden="true" />
            <span>กลับไปทุกช่องทาง</span>
          </button>

          <div className="text-[13px] tabular-nums" style={{ color: 'var(--muted)' }}>
            ยอดคงเหลือ{' '}
            <strong style={{ color: 'var(--text)' }} data-testid="wallet-balance">
              {formatBaht(walletBalance)}
            </strong>
          </div>
        </div>

        <div className="mb-4 flex items-center gap-3.5">
          <img
            src={activeHeaderLogo}
            alt={channelMeta.label}
            className="w-12 h-12 rounded-full object-cover shrink-0 bg-white"
            style={{ border: '1px solid var(--line)' }}
          />
          <div className="min-w-0">
            <h3 className="m-0 text-[20px] font-semibold tracking-[-0.01em]">{channelMeta.label}</h3>
            <p className="mt-0.5 mb-0 text-[13.5px]" style={{ color: 'var(--muted)' }}>
              {channelMeta.description}
            </p>
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="rounded-[18px] p-4"
          style={{ background: 'var(--card)' }}
          noValidate
        >
          {(activeChannel === 'bank' && bankStep === 1) || activeChannel === 'cash' ? (
            <>
              {activeChannel === 'bank' ? (
                <div className="flex items-center justify-between text-[12.5px] mb-2.5" style={{ color: 'var(--muted)' }}>
                  <span>ขั้นตอนที่ 1/2 · ระบุยอดและธนาคารที่โอน</span>
                </div>
              ) : null}
              <div className="text-[13px] mb-2" style={{ color: 'var(--muted)' }}>
                จำนวนเงิน (บาท)
              </div>
              <input
                id="topup-amount"
                type="number"
                min={1}
                step={1}
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="กรอกจำนวนเงิน (บาท)"
                aria-label="จำนวนเงิน (บาท)"
                className="mjk-field"
                style={{ background: 'var(--card2)' }}
              />
            </>
          ) : null}

          {activeChannel === 'truemoney' ? (
            <div className="space-y-2.5">
              <div className="text-[13px]" style={{ color: 'var(--muted)' }}>
                วางลิงก์ซองอั่งเปา TrueMoney (ตรวจยอดและเข้าวอลเล็ตอัตโนมัติ)
              </div>
              <input
                id="tm-angpao-url"
                type="url"
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                placeholder="วางลิงก์ซองอั่งเปา เช่น https://gift.truemoney.com/campaign/?v=..."
                aria-label="ลิงก์ซองอั่งเปา TrueMoney"
                className="mjk-field"
                style={{ background: 'var(--card2)' }}
              />
            </div>
          ) : null}

          {activeChannel === 'bank' && bankStep === 1 ? (
            <div className="mt-3 space-y-2.5">
              <div className="text-[13px]" style={{ color: 'var(--muted)' }}>
                ธนาคารที่โอน ({BANK_LIST.length} ธนาคาร / พร้อมเพย์)
              </div>

              <div ref={bankDropdownRef} className="relative">
                <button
                  id="bank-dropdown-trigger"
                  type="button"
                  aria-haspopup="listbox"
                  aria-expanded={bankMenuOpen}
                  aria-label="เลือกธนาคารที่โอน"
                  onClick={() => setBankMenuOpen((prev) => !prev)}
                  className="mjk-field !flex items-center justify-between gap-3 cursor-pointer text-left"
                  style={{ background: 'var(--card2)' }}
                >
                  <span className="flex items-center gap-3 min-w-0">
                    <img
                      src={selectedBank.logo}
                      alt={selectedBank.shortName}
                      className="w-7 h-7 rounded-full object-cover shrink-0 bg-white"
                      style={{ border: '1px solid var(--line)' }}
                    />
                    <span className="truncate font-medium text-[15px]">{selectedBank.name}</span>
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 shrink-0 transition-transform duration-150 ${bankMenuOpen ? 'rotate-180' : ''}`}
                    style={{ color: 'var(--muted)' }}
                    aria-hidden="true"
                  />
                </button>

                {bankMenuOpen ? (
                  <div
                    role="listbox"
                    aria-label="รายชื่อธนาคารทั้งหมด"
                    className="absolute left-0 right-0 mt-1.5 max-h-[280px] overflow-y-auto rounded-[16px] p-1.5 shadow-xl z-20"
                    style={{
                      background: 'var(--panel)',
                      border: '1px solid var(--line)',
                    }}
                  >
                    {BANK_LIST.map((b) => {
                      const selected = bankName === b.name;
                      return (
                        <button
                          key={b.name}
                          type="button"
                          role="option"
                          aria-selected={selected}
                          onClick={() => {
                            setBankName(b.name);
                            setBankMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-[12px] text-left transition-colors"
                          style={{
                            background: selected ? 'var(--card2)' : 'transparent',
                            color: 'var(--text)',
                          }}
                        >
                          <img
                            src={b.logo}
                            alt={b.shortName}
                            className="w-7 h-7 rounded-full object-cover shrink-0 bg-white"
                            style={{ border: '1px solid var(--line)' }}
                          />
                          <span className="flex-1 min-w-0 truncate text-[14.5px] font-medium">
                            {b.name}
                          </span>
                          {selected ? (
                            <Check
                              className="w-4 h-4 shrink-0"
                              style={{ color: 'var(--accent)' }}
                              aria-hidden="true"
                            />
                          ) : null}
                        </button>
                      );
                    })}
                  </div>
                ) : null}
              </div>
            </div>
          ) : null}

          {activeChannel === 'bank' && bankStep === 2 ? (
            <div className="space-y-3.5" data-testid="bank-step-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setBankStep(1);
                    setErrorMsg('');
                  }}
                  className="mjk-sm inline-flex items-center gap-1.5"
                  style={{ padding: '7px 12px' }}
                >
                  <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>ย้อนกลับ</span>
                </button>
                <span className="text-[12.5px]" style={{ color: 'var(--muted)' }}>
                  ขั้นตอนที่ 2/2 · โอนเงินและแนบสลิป
                </span>
              </div>

              <div
                className="rounded-2xl px-4 py-3 flex items-center justify-between gap-3"
                style={{ background: 'var(--card2)' }}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <img
                    src={selectedBank.logo}
                    alt={selectedBank.shortName}
                    className="w-7 h-7 rounded-full object-cover shrink-0 bg-white"
                    style={{ border: '1px solid var(--line)' }}
                  />
                  <div className="min-w-0">
                    <span className="block text-[11.5px]" style={{ color: 'var(--muted)' }}>
                      โอนจากธนาคาร
                    </span>
                    <strong className="block text-[14px] font-medium truncate">
                      {selectedBank.name}
                    </strong>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="block text-[11.5px]" style={{ color: 'var(--muted)' }}>
                    ยอดโอน
                  </span>
                  <strong className="text-[18px] font-semibold tabular-nums" style={{ color: 'var(--accent)' }}>
                    {formatBaht(Math.round(Number(amount)))}
                  </strong>
                </div>
              </div>

              <div
                className="rounded-2xl p-4 space-y-3.5"
                style={{ background: 'var(--card2)' }}
              >
                <div className="text-center">
                  <div className="text-[13px] mb-2.5" style={{ color: 'var(--muted)' }}>
                    สแกน QR Code หรือโอนเข้าบัญชีด้านล่าง
                  </div>
                  <div className="inline-block bg-white p-2.5 rounded-2xl">
                    <img
                      src={BANK_RECEIVER_ACCOUNT.qrImage}
                      alt={`คิวอาร์โค้ดรับโอนเงิน ${BANK_RECEIVER_ACCOUNT.shortName} ${BANK_RECEIVER_ACCOUNT.accountName}`}
                      className="w-[196px] h-[196px] sm:w-[212px] sm:h-[212px] object-contain rounded-lg"
                    />
                  </div>
                </div>

                <div
                  className="pt-3 flex items-center justify-between gap-3 flex-wrap"
                  style={{ borderTop: '1px solid var(--line)' }}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={BANK_RECEIVER_ACCOUNT.logo}
                      alt={BANK_RECEIVER_ACCOUNT.shortName}
                      className="w-10 h-10 rounded-full object-cover shrink-0 bg-white"
                      style={{ border: '1px solid var(--line)' }}
                    />
                    <div className="min-w-0">
                      <div className="text-[13px]" style={{ color: 'var(--muted)' }}>
                        {BANK_RECEIVER_ACCOUNT.shortName}
                      </div>
                      <div className="font-semibold text-[17px] tracking-wide tabular-nums">
                        {BANK_RECEIVER_ACCOUNT.accountNumber}
                      </div>
                      <div className="text-[13.5px]">
                        <span style={{ color: 'var(--muted)' }}>ชื่อบัญชี </span>
                        <strong className="font-medium">{BANK_RECEIVER_ACCOUNT.accountName}</strong>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleCopyAccount}
                    className="mjk-sm inline-flex items-center gap-1.5 shrink-0"
                    style={{ padding: '8px 13px' }}
                    aria-label="คัดลอกเลขบัญชี"
                  >
                    {copiedAccount ? (
                      <>
                        <Check className="w-3.5 h-3.5" style={{ color: 'var(--accent)' }} aria-hidden="true" />
                        <span>คัดลอกแล้ว</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>คัดลอกเลขบัญชี</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div>
                <div className="text-[13px] mb-2" style={{ color: 'var(--muted)' }}>
                  แนบสลิปการโอนเงิน
                </div>
                <input
                  ref={slipInputRef}
                  id="bank-slip-input"
                  type="file"
                  accept="image/*"
                  onChange={handleSlipChange}
                  aria-label="แนบสลิปการโอนเงิน"
                  className="sr-only"
                />

                {slipImage ? (
                  <div
                    className="rounded-2xl p-3 space-y-2.5"
                    style={{ background: 'var(--card2)' }}
                  >
                    <div className="relative flex justify-center rounded-xl overflow-hidden bg-black/20">
                      <img
                        src={slipImage}
                        alt="ตัวอย่างสลิปโอนเงินที่แนบ"
                        className="max-h-[240px] w-auto object-contain rounded-xl"
                      />
                      <button
                        type="button"
                        onClick={() => setSlipImage('')}
                        aria-label="ลบสลิปที่แนบ"
                        className="absolute top-2 right-2 w-8 h-8 rounded-full grid place-items-center bg-black/70 text-white hover:bg-black/90 transition-colors"
                      >
                        <X className="w-4 h-4" aria-hidden="true" />
                      </button>
                    </div>
                    <button
                      type="button"
                      disabled={slipUploading}
                      onClick={() => slipInputRef.current?.click()}
                      className="w-full min-h-[40px] px-3 py-2 rounded-xl flex items-center justify-center gap-2 text-[13.5px] font-medium transition-colors"
                      style={{ background: 'var(--card)', color: 'var(--text)' }}
                    >
                      <ImagePlus className="w-4 h-4" aria-hidden="true" />
                      <span>เปลี่ยนรูปสลิป</span>
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    disabled={slipUploading}
                    onClick={() => slipInputRef.current?.click()}
                    className="w-full min-h-[48px] px-4 py-3 rounded-2xl flex items-center justify-center gap-2 text-[14.5px] font-medium transition-colors disabled:opacity-45"
                    style={{
                      background: 'var(--card2)',
                      color: 'var(--text)',
                      border: '1px dashed var(--line)',
                    }}
                  >
                    <ImagePlus className="w-[18px] h-[18px]" aria-hidden="true" />
                    <span>{slipUploading ? 'กำลังประมวลผลสลิป...' : 'แนบสลิปโอนเงิน'}</span>
                  </button>
                )}
              </div>
            </div>
          ) : null}

          {activeChannel === 'cash' ? (
            <div className="mt-2.5 space-y-2.5">
              <div
                className="rounded-2xl px-4 py-3 text-[14px]"
                style={{ background: 'var(--card2)', color: 'var(--text)' }}
              >
                <span style={{ color: 'var(--muted)' }}>จุดนัดรับเงินสด: </span>
                <strong className="font-medium">{CASH_MEETUP_LOCATION}</strong>{' '}
                <span style={{ color: 'var(--muted)' }}>(นัดรับเฉพาะจุดนี้เท่านั้น)</span>
              </div>
              <input
                id="cash-note"
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="หมายเหตุเพิ่มเติม (ถ้ามี) เช่น จ่ายพักเที่ยง"
                aria-label="หมายเหตุเพิ่มเติม"
                className="mjk-field"
                style={{ background: 'var(--card2)' }}
              />
            </div>
          ) : null}

          {activeChannel === 'giftcode' ? (
            <div>
              <div className="text-[13px] mb-2" style={{ color: 'var(--muted)' }}>
                กรอกรหัสกิ๊ฟโค๊ด (เข้ายอดทันที)
              </div>
              <input
                id="gift-code"
                type="text"
                value={giftCode}
                onChange={(e) => setGiftCode(e.target.value)}
                placeholder="กรอกรหัส เช่น WEI50"
                aria-label="รหัสกิ๊ฟโค๊ด"
                className="mjk-field uppercase"
                style={{ background: 'var(--card2)' }}
              />
              <p className="mt-2 mb-0 text-[12.5px]" style={{ color: 'var(--muted)' }}>
                โค้ดที่พร้อมใช้:{' '}
                {giftCodes
                  .filter((g) => !usedGiftCodes.includes(g.code.toUpperCase()))
                  .map((g) => `${g.code} (${formatBaht(g.amount)})`)
                  .join(' · ') || 'ใช้ครบทั้งหมดแล้ว'}
              </p>
            </div>
          ) : null}

          {errorMsg ? (
            <p role="alert" className="mt-3 mb-0 text-[13.5px] text-[#ff6b6b]">
              {errorMsg}
            </p>
          ) : null}

          {statusMsg ? (
            <p role="status" className="mt-3 mb-0 text-[13.5px]" style={{ color: 'var(--accent)' }}>
              {statusMsg}
            </p>
          ) : null}

          <button type="submit" disabled={angpaoLoading || slipUploading} className="mjk-primary mt-3.5">
            {activeChannel === 'giftcode'
              ? 'ใช้กิ๊ฟโค๊ด'
              : activeChannel === 'truemoney'
                ? angpaoLoading
                  ? 'กำลังตรวจสอบซองอั่งเปา...'
                  : 'รับเงินจากซองอั่งเปา'
                : activeChannel === 'bank'
                  ? bankStep === 1
                    ? 'ต่อไป'
                    : 'ยืนยันแจ้งเติมเงิน'
                  : `แจ้งเติมเงิน ${channelMeta.label}`}
          </button>
        </form>

        {isAdmin && activeChannel === 'giftcode' ? (
          <div className="rounded-[18px] p-4 mt-3" style={{ background: 'var(--card)' }}>
            <div className="font-medium text-[15px] mb-2">แอดมิน: เพิ่มกิ๊ฟโค๊ดใหม่</div>
            <div className="flex flex-wrap gap-2">
              <input
                type="text"
                value={newCode}
                onChange={(e) => setNewCode(e.target.value)}
                placeholder="รหัสโค้ด เช่น WEI300"
                aria-label="รหัสกิ๊ฟโค๊ดใหม่"
                className="mjk-field flex-1 min-w-[130px] !h-10 !rounded-xl uppercase"
                style={{ background: 'var(--card2)' }}
              />
              <input
                type="number"
                min={1}
                value={newCodeAmount}
                onChange={(e) => setNewCodeAmount(e.target.value)}
                placeholder="บาท"
                aria-label="มูลค่ากิ๊ฟโค๊ดใหม่"
                className="mjk-field w-28 !h-10 !rounded-xl"
                style={{ background: 'var(--card2)' }}
              />
              <button
                type="button"
                onClick={handleCreateGiftCode}
                className="mjk-sm on"
                style={{ padding: '9px 16px' }}
              >
                เพิ่มโค้ด
              </button>
            </div>
          </div>
        ) : null}

        <div className="mt-6 mb-2 text-[13px]" style={{ color: 'var(--muted)' }}>
          ประวัติช่องทาง {channelMeta.label}
        </div>
        {renderHistoryList(channelRecords, `ยังไม่มีรายการเติมเงินผ่าน ${channelMeta.label}`)}

        {previewSlip && typeof document !== 'undefined'
          ? createPortal(
              <div
                role="dialog"
                aria-modal="true"
                aria-label="ดูสลิปโอนเงิน"
                onClick={() => setPreviewSlip(null)}
                className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-5"
              >
                <button
                  type="button"
                  aria-label="ปิดสลิปตัวอย่าง"
                  onClick={() => setPreviewSlip(null)}
                  className="absolute top-4 right-4 w-11 h-11 rounded-full grid place-items-center bg-white/15 text-white hover:bg-white/25 transition-colors"
                >
                  <X className="w-5 h-5" aria-hidden="true" />
                </button>
                <img
                  src={previewSlip}
                  alt="สลิปโอนเงินขนาดเต็ม"
                  onClick={(e) => e.stopPropagation()}
                  className="max-w-full max-h-[85vh] rounded-2xl object-contain"
                />
              </div>,
              document.body
            )
          : null}
      </div>
    );
  }

  return (
    <div>
      <p className="mt-0 mb-4" style={{ color: 'var(--muted)' }}>
        เลือกการ์ดช่องทางที่ต้องการเติมเงิน เพื่อเข้าไปกรอกข้อมูลและเช็กประวัติของแต่ละช่องทาง
      </p>

      <div
        className="grid grid-cols-2 mb-5"
        style={{ borderTop: '1px solid var(--line)', borderBottom: '1px solid var(--line)' }}
      >
        <div className="py-3.5 text-center">
          <b className="block text-[22px] font-semibold tabular-nums" data-testid="wallet-balance">
            {formatBaht(walletBalance)}
          </b>
          <span className="text-[13px]" style={{ color: 'var(--muted)' }}>
            ยอดเงินคงเหลือ
          </span>
        </div>
        <div className="py-3.5 text-center" style={{ borderLeft: '1px solid var(--line)' }}>
          <b className="block text-[22px] font-semibold tabular-nums" data-testid="wallet-pending">
            {formatBaht(pendingAmount)}
          </b>
          <span className="text-[13px]" style={{ color: 'var(--muted)' }}>
            รอตรวจสอบ
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3" data-testid="topup-channel-cards">
        {TOPUP_CHANNELS.map((ch) => {
          const chRecords = topups.filter((t) => t.channel === ch.key);
          const chTotal = chRecords.reduce((s, r) => s + r.amount, 0);

          return (
            <button
              key={ch.key}
              type="button"
              onClick={() => openChannel(ch.key)}
              aria-label={`เปิดหน้าเติมเงิน ${ch.label}`}
              data-testid={`channel-card-${ch.key}`}
              className="rounded-[18px] p-4 flex flex-col justify-between gap-3.5 text-left group transition-transform active:scale-[0.985]"
              style={{ background: 'var(--card)' }}
            >
              <div className="w-full flex items-start gap-3.5">
                <img
                  src={ch.logo}
                  alt={ch.label}
                  className="w-12 h-12 rounded-full object-cover shrink-0 bg-white"
                  style={{ border: '1px solid var(--line)' }}
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <b className="font-semibold text-[16px] block truncate">{ch.label}</b>
                    <ChevronRight
                      className="w-4 h-4 shrink-0 transition-transform group-hover:translate-x-0.5"
                      style={{ color: 'var(--accent)' }}
                      aria-hidden="true"
                    />
                  </div>
                  <p className="mt-1 mb-0 text-[13px] leading-snug" style={{ color: 'var(--muted)' }}>
                    {ch.description}
                  </p>
                </div>
              </div>

              {ch.key === 'bank' ? (
                <div className="flex items-center gap-1.5 pl-[62px]">
                  {BANK_LIST.slice(0, 6).map((b) => (
                    <img
                      key={b.name}
                      src={b.logo}
                      alt={b.shortName}
                      title={b.shortName}
                      className="w-6 h-6 rounded-full object-cover bg-white"
                      style={{ border: '1px solid var(--line)' }}
                    />
                  ))}
                  <span className="text-[12px] font-medium tabular-nums ml-0.5" style={{ color: 'var(--muted)' }}>
                    +{BANK_LIST.length - 6}
                  </span>
                </div>
              ) : null}

              <div
                className="w-full pt-2.5 flex items-center justify-between text-[12.5px] tabular-nums"
                style={{ borderTop: '1px solid var(--line)', color: 'var(--muted)' }}
              >
                <span>
                  {chRecords.length} รายการ · {formatBaht(chTotal)}
                </span>
                <span className="font-medium" style={{ color: 'var(--accent)' }}>
                  {ch.key === 'giftcode' ? 'ใช้โค้ด' : 'เติมเงิน'}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      <div className="mt-6 mb-2 text-[13px]" style={{ color: 'var(--muted)' }}>
        ประวัติการเติมเงินทั้งหมด
      </div>
      {renderHistoryList(topups, 'ยังไม่มีรายการเติมเงิน')}

      {previewSlip && typeof document !== 'undefined'
        ? createPortal(
            <div
              role="dialog"
              aria-modal="true"
              aria-label="ดูสลิปโอนเงิน"
              onClick={() => setPreviewSlip(null)}
              className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-5"
            >
              <button
                type="button"
                aria-label="ปิดสลิปตัวอย่าง"
                onClick={() => setPreviewSlip(null)}
                className="absolute top-4 right-4 w-11 h-11 rounded-full grid place-items-center bg-white/15 text-white hover:bg-white/25 transition-colors"
              >
                <X className="w-5 h-5" aria-hidden="true" />
              </button>
              <img
                src={previewSlip}
                alt="สลิปโอนเงินขนาดเต็ม"
                onClick={(e) => e.stopPropagation()}
                className="max-w-full max-h-[85vh] rounded-2xl object-contain"
              />
            </div>,
            document.body
          )
        : null}
    </div>
  );
}
