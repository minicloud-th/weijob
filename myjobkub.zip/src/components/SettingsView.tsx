import { useState, useRef } from 'react';
import type { Order, ThemeMode } from '../types/myjobkub';
import { ACCENTS, formatBaht, getConfirmedTotal } from '../utils/myjobkubLogic';

interface SettingsViewProps {
  name: string;
  contact: string;
  orders: Order[];
  mode: ThemeMode;
  accent: string;
  isAdmin: boolean;
  adminPin: string;
  onUpdateName: (name: string) => void;
  onUpdateContact: (contact: string) => void;
  onChangeMode: (mode: ThemeMode) => void;
  onChangeAccent: (accent: string) => void;
  onEnterAdmin: () => void;
  onExitAdmin: () => void;
  onChangePin: (newPin: string) => void;
  onWipeOrders: () => void;
  onLogout: () => void;
}

const THEME_OPTIONS: Array<{ key: ThemeMode; label: string }> = [
  { key: 'light', label: 'สว่าง' },
  { key: 'dark', label: 'มืด' },
  { key: 'system', label: 'ระบบ' },
];

export function SettingsView({
  name,
  contact,
  orders,
  mode,
  accent,
  isAdmin,
  adminPin,
  onUpdateName,
  onUpdateContact,
  onChangeMode,
  onChangeAccent,
  onEnterAdmin,
  onExitAdmin,
  onChangePin,
  onWipeOrders,
  onLogout,
}: SettingsViewProps) {
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);
  const [newPinInput, setNewPinInput] = useState('');
  const [pinChanged, setPinChanged] = useState(false);
  const [confirmWipe, setConfirmWipe] = useState(false);

  const pinInputRef = useRef<HTMLInputElement>(null);
  const newPinRef = useRef<HTMLInputElement>(null);

  const confirmedTotal = getConfirmedTotal(orders);

  const handleEnterAdmin = () => {
    if (pinInput === adminPin) {
      setPinError(false);
      setPinInput('');
      onEnterAdmin();
    } else {
      setPinError(true);
      pinInputRef.current?.focus();
    }
  };

  const handleSaveNewPin = () => {
    const trimmed = newPinInput.trim();
    if (trimmed.length < 4) {
      newPinRef.current?.focus();
      return;
    }
    onChangePin(trimmed);
    setNewPinInput('');
    setPinChanged(true);
  };

  const handleWipeClick = () => {
    if (confirmWipe) {
      onWipeOrders();
      setConfirmWipe(false);
    } else {
      setConfirmWipe(true);
    }
  };

  return (
    <div>
      <div className="mt-6 mb-2 text-[13px]" style={{ color: 'var(--muted)' }}>
        ข้อมูลของฉัน
      </div>
      <div className="rounded-[18px] py-4 px-[18px] mt-2.5" style={{ background: 'var(--card)' }}>
        <input
          id="pn"
          className="mjk-field"
          value={name}
          onChange={(e) => onUpdateName(e.target.value)}
          onBlur={(e) => onUpdateName(e.target.value.trim())}
          placeholder="ชื่อ"
          aria-label="ชื่อ"
          style={{ background: 'var(--card2)' }}
        />
        <input
          id="pc"
          className="mjk-field mt-2.5"
          value={contact}
          onChange={(e) => onUpdateContact(e.target.value)}
          onBlur={(e) => onUpdateContact(e.target.value.trim())}
          placeholder="เบอร์โทรหรืออีเมล"
          aria-label="ช่องทางติดต่อ"
          style={{ background: 'var(--card2)' }}
        />
      </div>

      <div
        className="grid grid-cols-2 mt-3.5"
        style={{ borderTop: '1px solid var(--line)', borderBottom: '1px solid var(--line)' }}
      >
        <div className="py-3.5 text-center">
          <b className="block text-[22px] font-semibold tabular-nums">{orders.length}</b>
          <span className="text-[13px]" style={{ color: 'var(--muted)' }}>
            งานทั้งหมด
          </span>
        </div>
        <div className="py-3.5 text-center" style={{ borderLeft: '1px solid var(--line)' }}>
          <b className="block text-[22px] font-semibold tabular-nums">
            {formatBaht(confirmedTotal)}
          </b>
          <span className="text-[13px]" style={{ color: 'var(--muted)' }}>
            ยอดที่ตกลงแล้ว
          </span>
        </div>
      </div>

      <div className="mt-6 mb-2 text-[13px]" style={{ color: 'var(--muted)' }}>
        การแสดงผล
      </div>
      <div className="rounded-[18px] py-4 px-[18px] mt-2.5" style={{ background: 'var(--card)' }}>
        <div className="flex items-center gap-3 w-full text-left">
          <b className="font-medium">โหมดสี</b>
          <div
            className="ml-auto flex gap-0.5 p-[3px] rounded-full"
            style={{ background: 'var(--card2)' }}
          >
            {THEME_OPTIONS.map((opt) => {
              const active = opt.key === mode;
              return (
                <button
                  key={opt.key}
                  type="button"
                  aria-pressed={active}
                  onClick={() => onChangeMode(opt.key)}
                  className="py-[5px] px-3.5 rounded-full text-[13px] whitespace-nowrap shrink-0 transition-colors"
                  style={{
                    background: active ? 'var(--hi)' : 'transparent',
                    color: active ? 'var(--text)' : 'var(--muted)',
                  }}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex items-center gap-3 w-full text-left mt-3.5">
          <b className="font-medium">สีหลัก</b>
        </div>
        <div className="flex gap-3 mt-3.5 flex-wrap">
          {ACCENTS.map((swatch, idx) => {
            const active = swatch === accent;
            return (
              <button
                key={swatch}
                type="button"
                aria-label={`สี ${idx + 1}`}
                aria-pressed={active}
                onClick={() => onChangeAccent(swatch)}
                className="w-[26px] h-[26px] rounded-full transition-transform"
                style={{
                  background: swatch,
                  outline: active ? '2px solid var(--text)' : 'none',
                  outlineOffset: active ? '3px' : '0px',
                }}
              />
            );
          })}
        </div>
      </div>

      <div className="mt-6 mb-2 text-[13px]" style={{ color: 'var(--muted)' }}>
        แอดมิน
      </div>
      <div className="rounded-[18px] py-4 px-[18px] mt-2.5" style={{ background: 'var(--card)' }}>
        {isAdmin ? (
          <>
            <div className="flex items-center gap-3 w-full text-left">
              <b className="font-medium">โหมดแอดมินเปิดอยู่</b>
            </div>
            <div className="flex flex-wrap gap-2 mt-3">
              <input
                ref={newPinRef}
                id="np"
                type="password"
                inputMode="numeric"
                value={newPinInput}
                onChange={(e) => {
                  setNewPinInput(e.target.value);
                  setPinChanged(false);
                }}
                placeholder="PIN ใหม่"
                aria-label="PIN ใหม่"
                className="mjk-field flex-1 min-w-[120px] !h-10 !rounded-xl"
                style={{ background: 'var(--card2)' }}
              />
              <button
                type="button"
                className="mjk-sm on"
                style={{ padding: '9px 16px' }}
                onClick={handleSaveNewPin}
              >
                {pinChanged ? 'เปลี่ยนแล้ว' : 'เปลี่ยน PIN'}
              </button>
              <button
                type="button"
                className="mjk-sm"
                style={{ padding: '9px 16px' }}
                onClick={onExitAdmin}
              >
                ออกจากโหมดแอดมิน
              </button>
            </div>
          </>
        ) : (
          <>
            <div className="flex flex-wrap gap-2">
              <input
                ref={pinInputRef}
                id="ap"
                type="password"
                inputMode="numeric"
                value={pinInput}
                onChange={(e) => {
                  setPinInput(e.target.value);
                  if (pinError) setPinError(false);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleEnterAdmin();
                  }
                }}
                placeholder="PIN แอดมิน"
                aria-label="PIN แอดมิน"
                className="mjk-field flex-1 min-w-[120px] !h-10 !rounded-xl"
                style={{ background: 'var(--card2)' }}
              />
              <button
                type="button"
                className="mjk-sm on"
                style={{ padding: '9px 16px' }}
                onClick={handleEnterAdmin}
              >
                เข้าโหมดแอดมิน
              </button>
            </div>
            {pinError ? (
              <p id="aerr" role="alert" className="mt-2.5 mx-1 mb-0 text-[13.5px] text-[#ff6b6b]">
                PIN ไม่ถูกต้อง
              </p>
            ) : null}
          </>
        )}
      </div>

      <div className="mt-6 mb-2 text-[13px]" style={{ color: 'var(--muted)' }}>
        บัญชี
      </div>
      <button
        type="button"
        onClick={handleWipeClick}
        className="flex items-center gap-3 w-full text-left rounded-[18px] py-4 px-[18px] mt-2.5"
        style={{ background: 'var(--card)' }}
      >
        <b className="font-medium text-[#ff6b6b]">
          {confirmWipe ? 'กดอีกครั้งเพื่อลบงานทั้งหมด' : 'ลบงานทั้งหมด'}
        </b>
      </button>

      <button
        type="button"
        onClick={onLogout}
        className="flex items-center gap-3 w-full text-left rounded-[18px] py-4 px-[18px] mt-2.5"
        style={{ background: 'var(--card)' }}
      >
        <b className="font-medium">ออกจากระบบ</b>
      </button>
    </div>
  );
}
