import { useState, useRef } from 'react';
import { X } from 'lucide-react';
import type { Order } from '../types/myjobkub';
import { formatBaht } from '../utils/myjobkubLogic';

interface OrdersViewProps {
  orders: Order[];
  isAdmin: boolean;
  walletBalance: number;
  onGoOrder: () => void;
  onGoTopUp: () => void;
  onSetPrice: (orderId: string, rawPrice: string) => boolean;
  onConfirmOrder: (orderId: string) => void;
  onPayOrder: (orderId: string) => void;
  onCompleteOrder: (orderId: string) => void;
  onDeleteOrder: (orderId: string) => void;
}

export function OrdersView({
  orders,
  isAdmin,
  walletBalance,
  onGoOrder,
  onGoTopUp,
  onSetPrice,
  onConfirmOrder,
  onPayOrder,
  onCompleteOrder,
  onDeleteOrder,
}: OrdersViewProps) {
  const [priceDrafts, setPriceDrafts] = useState<Record<string, string>>({});
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const priceInputRefs = useRef<Record<string, HTMLInputElement | null>>({});

  const getDraftPrice = (order: Order) => {
    if (priceDrafts[order.id] !== undefined) return priceDrafts[order.id];
    return order.price != null ? String(order.price) : '';
  };

  const handleSavePrice = (order: Order) => {
    const raw = getDraftPrice(order);
    const ok = onSetPrice(order.id, raw);
    if (!ok) {
      priceInputRefs.current[order.id]?.focus();
    }
  };

  return (
    <div>
      {isAdmin ? (
        <p className="mt-0 mb-[22px]" style={{ color: 'var(--muted)' }}>
          โหมดแอดมิน ตั้งราคาให้แต่ละงานด้านล่าง
        </p>
      ) : null}

      {orders.length === 0 ? (
        <>
          <p className="my-[18px] mx-0.5" style={{ color: 'var(--muted)' }}>
            {isAdmin ? 'ยังไม่มีงานเข้า' : 'ยังไม่มีงานเลย ส่งงานแรกได้เลย'}
          </p>
          {!isAdmin ? (
            <button type="button" className="mjk-primary" onClick={onGoOrder}>
              สั่งงาน
            </button>
          ) : null}
        </>
      ) : (
        orders.map((order) => {
          const quoteText =
            order.price == null ? 'รอแอดมินบอกราคา' : `ราคา ${formatBaht(order.price)}`;
          const isFinished = order.status === 'เสร็จแล้ว';

          return (
            <div
              key={order.id}
              className="rounded-[18px] py-4 px-[18px] mt-2.5"
              style={{ background: 'var(--card)' }}
            >
              <div className="flex items-center gap-3 w-full text-left">
                <div className="min-w-0">
                  <b className="font-medium block">{order.title}</b>
                  <small className="block text-[13px]" style={{ color: 'var(--muted)' }}>
                    {order.lv}
                    {order.qty.trim() ? ` · ${order.qty}` : ''} · ส่ง {order.due}
                  </small>
                  {order.note ? (
                    <small className="block text-[13px]" style={{ color: 'var(--muted)' }}>
                      {order.note}
                    </small>
                  ) : null}
                  <small className="block text-[13px]" style={{ color: 'var(--muted)' }}>
                    ติดต่อ {order.contact}
                  </small>
                </div>
                <span
                  className="ml-auto text-[13px] whitespace-nowrap shrink-0"
                  style={{ color: 'var(--muted)' }}
                >
                  {order.status}
                </span>
              </div>

              {order.images && order.images.length > 0 ? (
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 mt-3">
                  {order.images.map((src, idx) => (
                    <button
                      key={`${order.id}-img-${idx}`}
                      type="button"
                      onClick={() => setPreviewImage(src)}
                      aria-label={`ดูรูปที่ ${idx + 1} ของ ${order.title}`}
                      className="aspect-square rounded-xl overflow-hidden focus-visible:outline-2"
                      style={{ background: 'var(--card2)' }}
                    >
                      <img
                        src={src}
                        alt={`รูปรายละเอียด ${order.title} ${idx + 1}`}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-150"
                      />
                    </button>
                  ))}
                </div>
              ) : null}

              <div className="font-semibold mt-2 tabular-nums">
                {quoteText}
                {order.paid ? ' · ชำระจากวอลเล็ตแล้ว' : ''}
              </div>

              {isAdmin ? (
                <div className="flex flex-wrap gap-2 mt-3">
                  <input
                    ref={(el) => {
                      priceInputRefs.current[order.id] = el;
                    }}
                    type="number"
                    min={0}
                    step={1}
                    placeholder="ราคา (บาท)"
                    aria-label={`ราคาสำหรับ ${order.title}`}
                    value={getDraftPrice(order)}
                    onChange={(e) =>
                      setPriceDrafts((prev) => ({ ...prev, [order.id]: e.target.value }))
                    }
                    className="mjk-field flex-1 min-w-[120px] !h-10 !rounded-xl"
                    style={{ background: 'var(--card2)' }}
                  />
                  <button
                    type="button"
                    className="mjk-sm on"
                    style={{ padding: '9px 16px' }}
                    aria-label={`บันทึกราคา ${order.title}`}
                    onClick={() => handleSavePrice(order)}
                  >
                    บันทึกราคา
                  </button>
                  {order.status === 'ยืนยันแล้ว' ? (
                    <button
                      type="button"
                      className="mjk-sm"
                      style={{ padding: '9px 16px' }}
                      aria-label={`เสร็จแล้ว ${order.title}`}
                      onClick={() => onCompleteOrder(order.id)}
                    >
                      เสร็จแล้ว
                    </button>
                  ) : null}
                  <button
                    type="button"
                    className="mjk-sm"
                    style={{ padding: '9px 16px' }}
                    aria-label={`ลบ ${order.title}`}
                    onClick={() => onDeleteOrder(order.id)}
                  >
                    ลบ
                  </button>
                </div>
              ) : (
                <div className="flex flex-wrap gap-2 mt-3">
                  {order.status === 'เสนอราคาแล้ว' ? (
                    <button
                      type="button"
                      className="mjk-sm on"
                      style={{ padding: '9px 16px' }}
                      aria-label={`โอเค ตกลงราคานี้ ${order.title}`}
                      onClick={() => onConfirmOrder(order.id)}
                    >
                      โอเค ตกลงราคานี้
                    </button>
                  ) : null}
                  {order.status === 'ยืนยันแล้ว' && order.price != null && !order.paid ? (
                    walletBalance >= order.price ? (
                      <button
                        type="button"
                        className="mjk-sm on"
                        style={{ padding: '9px 16px' }}
                        aria-label={`จ่ายจากวอลเล็ต ${order.title}`}
                        onClick={() => onPayOrder(order.id)}
                      >
                        จ่ายจากวอลเล็ต ({formatBaht(order.price)})
                      </button>
                    ) : (
                      <button
                        type="button"
                        className="mjk-sm"
                        style={{ padding: '9px 16px' }}
                        onClick={onGoTopUp}
                      >
                        เติมเงินเพื่อจ่าย ({formatBaht(walletBalance)})
                      </button>
                    )
                  ) : null}
                  {!isFinished ? (
                    <button
                      type="button"
                      className="mjk-sm"
                      style={{ padding: '9px 16px' }}
                      aria-label={`ยกเลิก ${order.title}`}
                      onClick={() => onDeleteOrder(order.id)}
                    >
                      ยกเลิก
                    </button>
                  ) : null}
                </div>
              )}
            </div>
          );
        })
      )}

      {previewImage ? (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="ดูรูปรายละเอียด"
          onClick={() => setPreviewImage(null)}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-5"
        >
          <button
            type="button"
            aria-label="ปิดรูปตัวอย่าง"
            onClick={() => setPreviewImage(null)}
            className="absolute top-4 right-4 w-11 h-11 rounded-full grid place-items-center bg-white/15 text-white hover:bg-white/25 transition-colors"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
          <img
            src={previewImage}
            alt="รูปรายละเอียดขนาดเต็ม"
            onClick={(e) => e.stopPropagation()}
            className="max-w-full max-h-[85vh] rounded-2xl object-contain"
          />
        </div>
      ) : null}
    </div>
  );
}
