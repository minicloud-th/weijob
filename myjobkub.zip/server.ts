import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  extractVoucherHash,
  isValidThaiPhone,
  normalizeThaiPhone,
  parseAngpaoApiResponse,
} from './src/utils/angpaoLogic.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === 'production';

async function startServer() {
  const app = express();
  app.use(express.json());

  app.get('/api/angpao/config', (_req, res) => {
    const envPhone = normalizeThaiPhone(process.env.TRUEMONEY_RECEIVER_PHONE ?? '');
    res.json({
      hasServerReceiverPhone: isValidThaiPhone(envPhone),
    });
  });

  app.post('/api/angpao/redeem', async (req, res) => {
    const voucherUrl = typeof req.body?.voucherUrl === 'string' ? req.body.voucherUrl : '';
    const envPhone = process.env.TRUEMONEY_RECEIVER_PHONE ?? '';

    const voucherHash = extractVoucherHash(voucherUrl);
    if (!voucherHash) {
      res.status(400).json({
        ok: false,
        code: 'INVALID_VOUCHER_URL',
        error: 'ลิงก์ซองอั่งเปา TrueMoney ไม่ถูกต้อง กรุณาวางลิงก์ https://gift.truemoney.com/campaign/?v=...',
      });
      return;
    }

    const mobile = normalizeThaiPhone(envPhone);
    if (!isValidThaiPhone(mobile)) {
      res.status(400).json({
        ok: false,
        code: 'RECEIVER_PHONE_NOT_CONFIGURED',
        error: 'ยังไม่ได้ตั้งค่าเบอร์ TrueMoney รับซองอั่งเปาของร้านในเซิร์ฟเวอร์ (TRUEMONEY_RECEIVER_PHONE)',
      });
      return;
    }

    const endpoint = `https://gift.truemoney.com/campaign/vouchers/${voucherHash}/redeem`;

    try {
      const upstream = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          Origin: 'https://gift.truemoney.com',
          Referer: `https://gift.truemoney.com/campaign/?v=${voucherHash}`,
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        },
        body: JSON.stringify({ mobile }),
      });

      const contentType = upstream.headers.get('content-type') ?? '';
      if (!contentType.includes('application/json')) {
        res.status(502).json({
          ok: false,
          code: 'UPSTREAM_BLOCKED',
          error:
            'TrueMoney ปฏิเสธการเชื่อมต่อจากเซิร์ฟเวอร์ชั่วคราว (Cloudflare Challenge) กรุณาลองใหม่อีกครั้ง',
        });
        return;
      }

      const payload: unknown = await upstream.json();
      const parsed = parseAngpaoApiResponse(payload, voucherHash, mobile);

      if (!parsed.ok) {
        res.status(400).json(parsed);
        return;
      }

      res.json(parsed);
    } catch {
      res.status(502).json({
        ok: false,
        code: 'NETWORK_ERROR',
        error: 'ไม่สามารถเชื่อมต่อ API ซองอั่งเปา TrueMoney ได้ในขณะนี้ กรุณาลองใหม่',
      });
    }
  });

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, allowedHosts: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`weijob server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
